#!/bin/bash
# Copyright 2023 RobustMQ Team
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# RobustMQ Release Script (Simplified)
#
# This script provides essential GitHub release functionality:
# 1. Create GitHub release and upload current platform package
# 2. Upload current platform package to existing release
#
# Usage:
#   ./release-simple.sh [OPTIONS]
#
# Examples:
#   ./release-simple.sh                     # Create release for current platform
#   ./release-simple.sh --version v0.1.30  # Create release for specific version
#   ./release-simple.sh --upload-only      # Upload to existing release

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Get script and project directories
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

# Configuration variables (simplified)
VERSION="${VERSION:-}"
GITHUB_TOKEN="${GITHUB_TOKEN:-}"
GITHUB_REPO="${GITHUB_REPO:-robustmq/robustmq}"
UPLOAD_ONLY="${UPLOAD_ONLY:-false}"
UPLOAD_MAX_RETRIES="${UPLOAD_MAX_RETRIES:-5}"
UPLOAD_RETRY_DELAY="${UPLOAD_RETRY_DELAY:-15}"

# GitHub API base URL
GITHUB_API_URL="https://api.github.com"

# Helper functions
log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}" >&2
}

log_success() {
    echo -e "${GREEN}✅ $1${NC}" >&2
}

log_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}" >&2
}

log_error() {
    echo -e "${RED}❌ $1${NC}" >&2
}

log_step() {
    echo -e "${BOLD}${PURPLE}🚀 $1${NC}" >&2
}

show_help() {
    echo -e "${BOLD}${BLUE}RobustMQ Release Script (Simplified)${NC}"
    echo
    echo -e "${BOLD}USAGE:${NC}"
    echo "    $0 [OPTIONS]"
    echo
    echo -e "${BOLD}OPTIONS:${NC}"
    echo "    -h, --help                  Show this help message"
    echo "    -v, --version VERSION       Release version (default: auto-detect from Cargo.toml)"
    echo "    -t, --token TOKEN          GitHub personal access token"
    echo "    --upload-only              Only upload current platform to existing release"
    echo
    echo -e "${BOLD}ENVIRONMENT VARIABLES:${NC}"
    echo "    GITHUB_TOKEN              GitHub personal access token"
    echo "    VERSION                   Release version"
    echo "    UPLOAD_ONLY               Upload to existing release only (true/false)"
    echo "    UPLOAD_MAX_RETRIES         Maximum retry attempts for upload (default: 3)"
    echo "    UPLOAD_RETRY_DELAY         Initial delay in seconds between retries (default: 5)"
    echo
    echo -e "${BOLD}EXAMPLES:${NC}"
    echo "    # Create release for current platform"
    echo "    $0"
    echo
    echo "    # Create release with specific version"
    echo "    $0 --version v0.1.30"
    echo
    echo "    # Upload current platform to existing release"
    echo "    $0 --upload-only --version v0.1.30"
    echo
    echo -e "${BOLD}NOTES:${NC}"
    echo "    - Always builds and uploads current platform only"
    echo "    - Requires GitHub token with repo permissions"
    echo "    - Frontend is always built (no option to disable)"
}

extract_version_from_cargo() {
    local cargo_file="$PROJECT_ROOT/Cargo.toml"

    if [ ! -f "$cargo_file" ]; then
        log_error "Cargo.toml not found at $cargo_file"
        return 1
    fi

    # Try multiple methods to extract version
    local version=""
    
    # Method 1: Look for workspace.package version
    version=$(grep -A 10 "^\[workspace\.package\]" "$cargo_file" | grep "^version" | head -1 | sed 's/.*"\([^"]*\)".*/\1/')
    
    # Method 2: Look for regular package version if workspace version not found
    if [ -z "$version" ]; then
        version=$(grep -A 10 "^\[package\]" "$cargo_file" | grep "^version" | head -1 | sed 's/.*"\([^"]*\)".*/\1/')
    fi
    
    # Method 3: Simple fallback
    if [ -z "$version" ]; then
        version=$(grep "^version\s*=" "$cargo_file" | head -1 | sed 's/.*"\([^"]*\)".*/\1/')
    fi

    # Validate version format
    if [ -z "$version" ]; then
        log_error "Could not extract version from Cargo.toml"
        log_error "Please ensure version is defined in [package] or [workspace.package] section"
        return 1
    fi

    # Validate semantic version format (basic check)
    if ! echo "$version" | grep -qE '^[0-9]+\.[0-9]+\.[0-9]+(-[a-zA-Z0-9.-]+)?(\+[a-zA-Z0-9.-]+)?$'; then
        log_warning "Version '$version' may not follow semantic versioning format"
    fi

    # Add 'v' prefix if not present
    if [[ "$version" != v* ]]; then
        version="v$version"
    fi

    echo "$version"
}

check_dependencies() {
    local missing_deps=()

    if ! command -v curl >/dev/null 2>&1; then
        missing_deps+=("curl")
    fi

    if ! command -v jq >/dev/null 2>&1; then
        missing_deps+=("jq")
    fi

    if [ ${#missing_deps[@]} -ne 0 ]; then
        log_error "Missing required dependencies: ${missing_deps[*]}"
        return 1
    fi
}

detect_current_platform() {
    local os_type arch_type

    case "$(uname -s)" in
        Darwin)
            os_type="darwin"
            ;;
        Linux)
            os_type="linux"
            ;;
        *)
            log_error "Unsupported OS: $(uname -s)"
            return 1
            ;;
    esac

    case "$(uname -m)" in
        x86_64|amd64)
            arch_type="amd64"
            ;;
        arm64|aarch64)
            arch_type="arm64"
            ;;
        *)
            log_error "Unsupported architecture: $(uname -m)"
            return 1
            ;;
    esac

    echo "${os_type}-${arch_type}"
}

check_github_token() {
    if [ -z "$GITHUB_TOKEN" ]; then
        log_error "GitHub token is required. Set GITHUB_TOKEN environment variable or use --token option."
        return 1
    fi
}

github_api_request() {
    local method="$1"
    local endpoint="$2"
    local data="${3:-}"

    local response
    local http_code

    if [ -n "$data" ]; then
        response=$(curl -s -w "HTTPSTATUS:%{http_code}" \
            -X "$method" \
            -H "Authorization: token $GITHUB_TOKEN" \
            -H "Accept: application/vnd.github.v3+json" \
            -H "Content-Type: application/json" \
            -d "$data" \
            "$GITHUB_API_URL/repos/$GITHUB_REPO$endpoint")
    else
        response=$(curl -s -w "HTTPSTATUS:%{http_code}" \
            -X "$method" \
            -H "Authorization: token $GITHUB_TOKEN" \
            -H "Accept: application/vnd.github.v3+json" \
            "$GITHUB_API_URL/repos/$GITHUB_REPO$endpoint")
    fi

    http_code=$(echo "$response" | grep -o "HTTPSTATUS:[0-9]*" | cut -d: -f2)
    response_body=$(echo "$response" | sed 's/HTTPSTATUS:[0-9]*$//')

    if [ "$http_code" -ge 200 ] && [ "$http_code" -lt 300 ]; then
        echo "$response_body"
    else
        log_error "GitHub API request failed with HTTP $http_code"
        echo "$response_body"
        return 1
    fi
}

check_release_exists() {
    local version="$1"
    local response

    response=$(github_api_request "GET" "/releases/tags/$version" 2>/dev/null || echo '{"message": "Not Found"}')

    if echo "$response" | jq -e '.id' >/dev/null 2>&1; then
        echo "true"
    else
        echo "false"
    fi
}

generate_custom_release_notes() {
    local version="$1"
    local build_date=$(TZ='Asia/Shanghai' date '+%Y-%m-%d %H:%M:%S CST')
    
    cat << EOF
## 🚀 RobustMQ $version

Welcome to RobustMQ $version release!

### 📦 Assets

This release includes pre-built binaries for multiple platforms:

- **Linux AMD64** (\`robustmq-${version}-linux-amd64.tar.gz\`)
- **Linux ARM64** (\`robustmq-${version}-linux-arm64.tar.gz\`)
- **macOS AMD64** (\`robustmq-${version}-darwin-amd64.tar.gz\`)
- **macOS ARM64** (\`robustmq-${version}-darwin-arm64.tar.gz\`)

> **Note**: Platform-specific packages are uploaded incrementally. If your platform is not yet available, please check back shortly.

### 📥 Installation

1. **Download the package** for your platform from the assets below
2. **Extract the archive**:
   \`\`\`bash
   tar -xzf robustmq-${version}-<platform>.tar.gz
   cd robustmq-${version}-<platform>
   \`\`\`

3. **Review the directory structure**:
   - \`bin/\` - Management scripts (robust-server, robust-ctl, robust-bench)
   - \`libs/\` - Compiled binaries (broker-server, cli-command, cli-bench)
   - \`config/\` - Configuration files
   - \`dist/\` - Web UI (if included)
   - \`LICENSE\` - License file
   - \`package-info.txt\` - Package information

### ⚙️ Configuration

1. **Edit configuration files** in the \`config/\` directory according to your needs
2. **Main configuration file**:
   - \`config/server.toml\` - Server configuration (supports multiple roles: meta, broker, journal)
   - \`config/logger.toml\` - Logging and tracing configuration

### 🎯 Quick Start

**Start RobustMQ Server** (all-in-one mode):
\`\`\`bash
./bin/robust-server start
\`\`\`

**Start with custom configuration**:
\`\`\`bash
./bin/robust-server start config/server.toml
\`\`\`

**Stop the server**:
\`\`\`bash
./bin/robust-server stop
\`\`\`

**Access Web UI** (if frontend is included):
\`\`\`
http://localhost:8080
\`\`\`

**Management Tools**:
\`\`\`bash
# View cluster information
./bin/robust-ctl cluster info

# Run benchmarks
./bin/robust-bench --help
\`\`\`

**Test MQTT Connection**:
\`\`\`bash
# Install mqttx client (if not already installed)
npm install -g mqttx-cli

# Publish message
mqttx pub -h 127.0.0.1 -p 1883 -t "test/topic" -m "Hello RobustMQ!"

# Subscribe to messages
mqttx sub -h 127.0.0.1 -p 1883 -t "test/topic"
\`\`\`

### 📚 Documentation

- **Documentation**: [https://www.robustmq.com](https://www.robustmq.com)
- **GitHub Repository**: [https://github.com/robustmq/robustmq](https://github.com/robustmq/robustmq)
- **Issues**: [https://github.com/robustmq/robustmq/issues](https://github.com/robustmq/robustmq/issues)
- **Discussions**: [https://github.com/robustmq/robustmq/discussions](https://github.com/robustmq/robustmq/discussions)

### 🛠️ Build Information

- **Release Version**: $version
- **Build Date**: $build_date
- **Frontend Web UI**: Included (in packages with \`dist/\` directory)

### 📝 Notes

- For production deployments, please review and adjust the configuration files
- Make sure required ports are available and not blocked by firewall
- Check system requirements and dependencies before deployment
- For upgrade instructions, please refer to the documentation

### 💬 Community

Join our community to get help, share ideas, and contribute:

- **GitHub Discussions**: Ask questions and share knowledge
- **GitHub Issues**: Report bugs and request features
- **Contributing**: We welcome contributions! See CONTRIBUTING.md
EOF
}

create_github_release() {
    local version="$1"
    local response

    log_step "Creating GitHub release for version $version"

    # Generate custom release notes (installation guide, etc.)
    local custom_notes=$(generate_custom_release_notes "$version")
    
    # Escape the body for JSON
    local escaped_body=$(echo "$custom_notes" | jq -Rs .)

    # Use GitHub's auto-generate feature combined with our custom notes
    local release_data=$(cat << EOF
{
  "tag_name": "$version",
  "target_commitish": "main",
  "name": "RobustMQ $version",
  "body": $escaped_body,
  "draft": false,
  "prerelease": false,
  "generate_release_notes": true
}
EOF
)

    response=$(github_api_request "POST" "/releases" "$release_data")

    if echo "$response" | jq -e '.id' >/dev/null 2>&1; then
        local release_id=$(echo "$response" | jq -r '.id')
        log_success "GitHub release created successfully (ID: $release_id)"
        log_info "GitHub has automatically generated PR and contributor information"
        echo "$release_id"
    else
        log_error "Failed to create GitHub release"
        return 1
    fi
}

get_release_id() {
    local version="$1"
    local response

    response=$(github_api_request "GET" "/releases/tags/$version")

    if echo "$response" | jq -e '.id' >/dev/null 2>&1; then
        echo "$response" | jq -r '.id'
    else
        log_error "Failed to get release ID for $version"
        return 1
    fi
}

build_package() {
    local version="$1"
    local platform="$2"

    log_step "Building package for $platform"

    local build_cmd="$SCRIPT_DIR/build.sh --version $version --with-frontend"

    if ! $build_cmd; then
        log_error "Failed to build package"
        return 1
    fi

    log_success "Package built successfully"
}

upload_package() {
    local version="$1"
    local release_id="$2"
    local platform="$3"
    local build_dir="$PROJECT_ROOT/build"

    log_step "Uploading package to GitHub release"

    # Sanitize inputs: strip any whitespace/newlines that may have been
    # captured from command substitution output
    release_id=$(echo "$release_id" | tr -d '[:space:]')
    local repo
    repo=$(echo "$GITHUB_REPO" | tr -d '[:space:]')

    if [ -z "$release_id" ]; then
        log_error "release_id is empty - cannot build upload URL"
        return 1
    fi

    local tarball="$build_dir/robustmq-$version-$platform.tar.gz"

    if [ ! -f "$tarball" ]; then
        log_error "Package not found: $tarball"
        return 1
    fi

    local filename
    filename="$(basename "$tarball")"
    local upload_url="https://uploads.github.com/repos/${repo}/releases/${release_id}/assets?name=${filename}"

    log_info "Release ID: ${release_id}"
    log_info "Upload URL: ${upload_url}"

    local max_retries="${UPLOAD_MAX_RETRIES:-5}"
    local retry_delay="${UPLOAD_RETRY_DELAY:-15}"
    local attempt=1
    local response=""
    local http_code=""
    local response_body=""
    local last_error=""

    # Wait briefly before first upload attempt to let GitHub's upload endpoint
    # become fully ready after release creation (avoids transient 422 errors)
    log_info "Waiting 15s for GitHub release upload endpoint to be ready..."
    sleep 15

    while [ $attempt -le $max_retries ]; do
        if [ $attempt -gt 1 ]; then
            log_info "Retry attempt $attempt/$max_retries (waiting ${retry_delay}s before retry)..."
            sleep $retry_delay
            # Exponential backoff: double the delay for next retry
            retry_delay=$((retry_delay * 2))
        else
            log_info "Uploading $filename..."
        fi

        # Use curl with HTTP status code capture.
        # Temporarily disable set -e so curl failures are handled manually
        # instead of silently killing the script with curl's exit code.
        set +e
        response=$(curl -s -w "HTTPSTATUS:%{http_code}" \
            -H "Authorization: token $GITHUB_TOKEN" \
            -H "Content-Type: application/gzip" \
            --data-binary "@$tarball" \
            "$upload_url")
        curl_exit=$?
        set -e

        # Handle curl-level failure (network error, URL issue, etc.)
        if [ $curl_exit -ne 0 ]; then
            last_error="curl failed with exit code $curl_exit (network or URL error)"
            log_warning "$last_error"
            attempt=$((attempt + 1))
            continue
        fi

        http_code=$(echo "$response" | grep -o "HTTPSTATUS:[0-9]*" | cut -d: -f2 || true)
        response_body=$(echo "$response" | sed 's/HTTPSTATUS:[0-9]*$//' || true)

        # Guard against empty http_code (should not happen after curl success)
        if [ -z "$http_code" ]; then
            last_error="Could not parse HTTP status code from response"
            log_warning "$last_error (raw response: ${response:0:200})"
            attempt=$((attempt + 1))
            continue
        fi

        # Check if upload was successful (HTTP 201 Created or 200 OK)
        if [ "$http_code" -eq 201 ] || [ "$http_code" -eq 200 ]; then
            if echo "$response_body" | jq -e '.id' >/dev/null 2>&1; then
                log_success "Successfully uploaded $filename (HTTP $http_code)"
                return 0
            else
                last_error="Upload returned HTTP $http_code but response body is invalid"
                log_warning "$last_error"
            fi
        elif [ "$http_code" -ge 500 ]; then
            # Server errors (5xx) are retryable
            last_error="Server error (HTTP $http_code)"
            log_warning "$last_error: $(echo "$response_body" | jq -r '.message // .error // "Unknown error"' 2>/dev/null || echo "$response_body")"
        elif [ "$http_code" -eq 429 ]; then
            # Rate limit (429) is retryable, but use longer delay
            last_error="Rate limit exceeded (HTTP 429)"
            log_warning "$last_error: Rate limit exceeded, will retry with longer delay"
            retry_delay=$((retry_delay * 2))
        elif [ "$http_code" -eq 422 ]; then
            # 422 can mean the asset already exists, or that the upload endpoint is not ready yet.
            local error_msg
            error_msg=$(echo "$response_body" | jq -r '.message // .error // ""' 2>/dev/null || echo "")
            # Use grep -iE for portable extended regex (works on both GNU and BSD grep)
            if echo "$error_msg" | grep -iE "already_exists|already exists" >/dev/null 2>&1; then
                log_warning "Asset $filename already exists on this release, skipping upload"
                return 0
            fi
            last_error="Unprocessable Entity (HTTP 422): $error_msg"
            log_warning "$last_error - release upload endpoint may not be ready yet, retrying..."
        elif [ "$http_code" -eq 401 ] || [ "$http_code" -eq 403 ]; then
            # Auth errors are never retryable
            last_error="Authentication error (HTTP $http_code)"
            log_error "$last_error: $(echo "$response_body" | jq -r '.message // .error // "Unknown error"' 2>/dev/null || echo "$response_body")"
            log_error "Check your GITHUB_TOKEN permissions."
            return 1
        elif [ "$http_code" -eq 404 ]; then
            last_error="Release not found (HTTP 404)"
            log_error "$last_error: $(echo "$response_body" | jq -r '.message // .error // "Unknown error"' 2>/dev/null || echo "$response_body")"
            return 1
        elif [ "$http_code" -ge 400 ] && [ "$http_code" -lt 500 ]; then
            # Other 4xx errors: retry a limited number of times in case of transient issues
            last_error="Client error (HTTP $http_code)"
            log_warning "$last_error: $(echo "$response_body" | jq -r '.message // .error // "Unknown error"' 2>/dev/null || echo "$response_body")"
        else
            # Other errors (network issues, etc.)
            last_error="Upload failed (HTTP $http_code)"
            log_warning "$last_error: $(echo "$response_body" | jq -r '.message // .error // "Unknown error"' 2>/dev/null || echo "$response_body")"
        fi

        attempt=$((attempt + 1))
    done

    # All retries exhausted
    log_error "Failed to upload $filename after $max_retries attempts"
    log_error "Last error: $last_error"
    if [ -n "$response_body" ]; then
        log_error "Response: $response_body"
    fi
    return 1
}

main() {
    # Parse command line arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -v|--version)
                VERSION="$2"
                shift 2
                ;;
            -t|--token)
                GITHUB_TOKEN="$2"
                shift 2
                ;;
            --upload-only)
                UPLOAD_ONLY="true"
                shift
                ;;
            *)
                log_error "Unknown option: $1"
                echo "Use --help for usage information"
                exit 1
                ;;
        esac
    done

    # Extract version from Cargo.toml if not provided
    if [ -z "$VERSION" ]; then
        VERSION=$(extract_version_from_cargo)
        if [ $? -ne 0 ]; then
            exit 1
        fi
    fi

    # Ensure version has 'v' prefix
    if [[ "$VERSION" != v* ]]; then
        VERSION="v$VERSION"
    fi

    # Detect current platform
    local platform=$(detect_current_platform)
    if [ $? -ne 0 ]; then
        exit 1
    fi

    # Show configuration
    echo -e "${BOLD}${BLUE}🚀 RobustMQ Release Script (Simplified)${NC}" >&2
    echo >&2
    log_info "Version: $VERSION"
    log_info "Platform: $platform"
    log_info "Repository: $GITHUB_REPO"
    log_info "Upload Only: $UPLOAD_ONLY"
    echo >&2

    # Check dependencies and authentication
    log_step "Checking dependencies..."
    check_dependencies
    check_github_token

    local release_id=""

    if [ "$UPLOAD_ONLY" = "true" ]; then
        # Upload-only mode: check if release exists
        log_step "Checking if release exists..."
        local release_exists
        release_exists=$(check_release_exists "$VERSION")

        if [ "$release_exists" != "true" ]; then
            log_error "Release $VERSION does not exist"
            log_error "Upload-only mode requires an existing release"
            exit 1
        fi

        release_id=$(get_release_id "$VERSION")
        release_id=$(echo "$release_id" | tr -d '[:space:]')
        log_success "Release $VERSION exists (ID: $release_id)"
    else
        # Normal mode: create release if it doesn't exist
        log_step "Checking if release exists..."
        local release_exists
        release_exists=$(check_release_exists "$VERSION")

        if [ "$release_exists" = "true" ]; then
            log_info "Release $VERSION already exists"
            release_id=$(get_release_id "$VERSION")
        else
            release_id=$(create_github_release "$VERSION")
            if [ $? -ne 0 ]; then
                exit 1
            fi
        fi
        release_id=$(echo "$release_id" | tr -d '[:space:]')
    fi

    log_info "Using release ID: $release_id"

    # Build package
    build_package "$VERSION" "$platform"
    if [ $? -ne 0 ]; then
        exit 1
    fi

    # Upload package
    upload_package "$VERSION" "$release_id" "$platform"
    if [ $? -ne 0 ]; then
        exit 1
    fi

    # Show completion message
    echo
    log_success "Operation completed successfully!"
    log_info "GitHub Release: https://github.com/$GITHUB_REPO/releases/tag/$VERSION"
}

# Run main function
main "$@"
