CREATE TABLE `mqtt_user` (
`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
`username` varchar(100) DEFAULT NULL,
`password` varchar(100) DEFAULT NULL,
`salt` varchar(35) DEFAULT NULL,
`is_superuser` tinyint(1) DEFAULT 0,
`created` datetime DEFAULT NULL,
PRIMARY KEY (`id`),
UNIQUE KEY `mqtt_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mqtt_acl` (
`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
`username` varchar(100) DEFAULT NULL,
`permission` int(1) DEFAULT 1 COMMENT '0: deny, 1: allow',
`ipaddr` varchar(60) DEFAULT NULL COMMENT 'IpAddress',
`clientid` varchar(100) DEFAULT NULL COMMENT 'ClientId',
`access` int(2) NOT NULL COMMENT '0:All, 1: subscribe, 2: publish, 3: pubsub, 4: retain, 5: qos',
`topic` varchar(100) NOT NULL DEFAULT '' COMMENT 'Topic Filter',
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `mqtt_blacklist` (
`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
`blacklist_type` varchar(32) NOT NULL COMMENT 'ClientId/User/Ip/ClientIdMatch/UserMatch/IPCIDR',
`resource_name` varchar(255) NOT NULL COMMENT 'blacklist resource value',
`end_time` bigint unsigned NOT NULL DEFAULT 0 COMMENT '0 means no expiry',
`desc` varchar(255) NOT NULL DEFAULT '' COMMENT 'description',
PRIMARY KEY (`id`),
KEY `idx_blacklist_resource` (`resource_name`),
KEY `idx_blacklist_type` (`blacklist_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `mqtt_user` ( `username`, `password`, `salt`) VALUES
('robustmq', 'robustmq@2024', NULL);
