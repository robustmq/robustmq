// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

pub mod auth;
pub mod connector;
pub mod delay;
pub mod delay_task;
pub mod event;
pub mod packets;
pub mod publish;
pub mod session;
pub mod statistics;
pub mod subscribe;
pub mod time;
pub mod topic;

pub fn init() {
    statistics::init();
    event::init();
    auth::init();
    publish::init();
    delay::init();
    delay_task::init();
    session::init();
    packets::init();
}
