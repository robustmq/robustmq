// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use crate::{
    common::{
        channel::RequestChannel,
        connection_manager::ConnectionManager,
        tcp_acceptor::{acceptor_process, TcpAcceptorContext},
        tls_acceptor::{acceptor_tls_process, TlsAcceptorContext},
    },
    context::ServerContext,
};
use broker_core::cache::NodeCacheManager;
use common_base::error::ResultCommonError;
use common_base::task::TaskSupervisor;
use common_config::broker::broker_config;
use common_metrics::network::record_broker_thread_num;
use metadata_struct::connection::NetworkConnectionType;
use protocol::codec::RobustMQCodec;
use protocol::robust::RobustMQProtocol;
use rate_limit::global::GlobalRateLimiterManager;
use std::sync::Arc;
use std::time::Duration;
use tokio::net::TcpListener;
use tokio::sync::broadcast;
use tokio::time::sleep;
use tracing::{error, info};

pub struct TcpServer {
    name: String,
    connection_manager: Arc<ConnectionManager>,
    network_type: NetworkConnectionType,
    protocol: RobustMQProtocol,
    request_channel: Arc<RequestChannel>,
    acceptor_stop_send: broadcast::Sender<bool>,
    broker_cache: Arc<NodeCacheManager>,
    global_limit_manager: Arc<GlobalRateLimiterManager>,
    task_supervisor: Arc<TaskSupervisor>,
}

impl TcpServer {
    pub fn new(protocol: RobustMQProtocol, context: ServerContext) -> Self {
        let name = format!("{protocol:?}");
        let (acceptor_stop_send, _) = broadcast::channel(2);
        Self {
            name,
            network_type: context.network_type,
            protocol,
            connection_manager: context.connection_manager,
            request_channel: context.request_channel,
            acceptor_stop_send,
            broker_cache: context.broker_cache.clone(),
            global_limit_manager: context.global_limit_manager.clone(),
            task_supervisor: context.task_supervisor.clone(),
        }
    }

    pub async fn start(&self, tls: bool, port: u32) -> ResultCommonError {
        let listener = TcpListener::bind(format!("0.0.0.0:{port}")).await?;
        let arc_listener = Arc::new(listener);
        let codec = RobustMQCodec::new();
        let conf = broker_config();
        if tls {
            acceptor_tls_process(TlsAcceptorContext {
                accept_thread_num: conf.broker_network.accept_thread_num,
                listener: arc_listener.clone(),
                stop_sx: self.acceptor_stop_send.clone(),
                network_type: self.network_type.clone(),
                protocol: self.protocol.clone(),
                connection_manager: self.connection_manager.clone(),
                broker_cache: self.broker_cache.clone(),
                request_channel: self.request_channel.clone(),
                global_limit_manager: self.global_limit_manager.clone(),
                codec,
                task_supervisor: self.task_supervisor.clone(),
            })
            .await?;
        } else {
            acceptor_process(TcpAcceptorContext {
                accept_thread_num: conf.broker_network.accept_thread_num,
                connection_manager: self.connection_manager.clone(),
                broker_cache: self.broker_cache.clone(),
                stop_sx: self.acceptor_stop_send.clone(),
                listener: arc_listener.clone(),
                request_channel: self.request_channel.clone(),
                global_limit_manager: self.global_limit_manager.clone(),
                network_type: self.network_type.clone(),
                protocol: self.protocol.clone(),
                codec,
                task_supervisor: self.task_supervisor.clone(),
            })
            .await;
        }

        record_broker_thread_num(
            &self.network_type,
            (
                conf.broker_network.accept_thread_num,
                conf.broker_network.handler_thread_num,
            ),
        );
        info!(
            "{} {} Server started successfully, listening port: {port}",
            self.name, self.network_type
        );
        Ok(())
    }

    pub async fn stop(&self) {
        // Stop the acceptor thread and refuse to receive new data
        if let Err(e) = self.acceptor_stop_send.send(true) {
            error!(
                "Network type:{}, Failed to stop the acceptor thread. Error message: {:?}",
                self.network_type, e
            );
        }

        // Wait for the shared request channel to drain before stopping handler threads.
        loop {
            if self.request_channel.is_empty() {
                info!("[{}] All the request packets have been processed. Start to stop the request processing thread.", self.network_type);
                break;
            }
            let pending = self.request_channel.len();
            info!(
                "Request queue is not empty, current length {}, waiting for request packet processing to complete....",
                pending
            );
            sleep(Duration::from_secs(1)).await;
        }
    }
}
