// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use crate::common::{channel::RequestChannel, connection_manager::ConnectionManager};
use broker_core::cache::NodeCacheManager;
use common_base::task::TaskSupervisor;
use grpc_clients::pool::ClientPool;
use metadata_struct::connection::NetworkConnectionType;
use rate_limit::global::GlobalRateLimiterManager;
use std::sync::Arc;
use tokio::sync::broadcast;

#[derive(Clone)]
pub struct ServerContext {
    pub connection_manager: Arc<ConnectionManager>,
    pub global_limit_manager: Arc<GlobalRateLimiterManager>,
    pub client_pool: Arc<ClientPool>,
    pub network_type: NetworkConnectionType,
    pub broker_cache: Arc<NodeCacheManager>,
    pub stop_sx: broadcast::Sender<bool>,
    /// Shared request channel for all protocol acceptors.
    pub request_channel: Arc<RequestChannel>,
    pub task_supervisor: Arc<TaskSupervisor>,
}
