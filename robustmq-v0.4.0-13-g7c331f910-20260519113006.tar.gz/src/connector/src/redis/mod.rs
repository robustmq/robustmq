// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::collections::HashMap;
use std::sync::Arc;
use std::time::Duration;

use async_trait::async_trait;
use grpc_clients::pool::ClientPool;
use metadata_struct::{
    connector::config_redis::RedisConnectorConfig, connector::config_redis::RedisMode,
    connector::MQTTConnector, storage::record::StorageRecord,
};
use redis::aio::ConnectionManager;
use redis::{Client, Cmd, RedisError};
use rule_engine::apply_rule_engine;
use storage_adapter::driver::StorageDriverManager;
use tokio::sync::mpsc::Receiver;
use tracing::{error, info, warn};

use common_base::error::common::CommonError;

use super::{
    core::{BridgePluginReadConfig, BridgePluginThread},
    failure::FailureRecordInfo,
    loops::run_connector_loop,
    manager::ConnectorManager,
    traits::ConnectorSink,
};
pub struct RedisBridgePlugin {
    connector: MQTTConnector,
    config: RedisConnectorConfig,
}

impl RedisBridgePlugin {
    #[allow(clippy::result_large_err)]
    pub fn new(connector: MQTTConnector) -> Result<Self, CommonError> {
        let config = match &connector.connector_type {
            metadata_struct::connector::ConnectorType::Redis(config) => config.clone(),
            _ => {
                return Err(CommonError::CommonError(
                    "invalid connector type for redis plugin".to_string(),
                ));
            }
        };
        Ok(RedisBridgePlugin { connector, config })
    }

    fn build_redis_client(&self) -> Result<Client, RedisError> {
        let connection_info = match self.config.mode {
            RedisMode::Single => {
                let mut url = String::from("redis://");

                match (&self.config.username, &self.config.password) {
                    (Some(username), Some(password)) => {
                        url.push_str(&format!("{}:{}@", username, password));
                    }
                    (None, Some(password)) => {
                        url.push_str(&format!(":{}@", password));
                    }
                    _ => {}
                }

                url.push_str(&self.config.server);
                url.push_str(&format!("/{}", self.config.database));

                if self.config.tls_enabled {
                    url = url.replace("redis://", "rediss://");
                }

                info!("Connecting to Redis (single mode): {}", url);
                url
            }
            RedisMode::Cluster => {
                let mut url = String::from("redis://");

                match (&self.config.username, &self.config.password) {
                    (Some(username), Some(password)) => {
                        url.push_str(&format!("{}:{}@", username, password));
                    }
                    (None, Some(password)) => {
                        url.push_str(&format!(":{}@", password));
                    }
                    _ => {}
                }

                url.push_str(&self.config.server);

                if self.config.tls_enabled {
                    url = url.replace("redis://", "rediss://");
                }

                info!("Connecting to Redis (cluster mode): {}", url);
                url
            }
            RedisMode::Sentinel => {
                let mut url = String::from("redis+sentinel://");

                match (&self.config.username, &self.config.password) {
                    (Some(username), Some(password)) => {
                        url.push_str(&format!("{}:{}@", username, password));
                    }
                    (None, Some(password)) => {
                        url.push_str(&format!(":{}@", password));
                    }
                    _ => {}
                }

                url.push_str(&self.config.server);
                if let Some(master_name) = &self.config.sentinel_master_name {
                    url.push_str(&format!("/{}", master_name));
                }

                info!("Connecting to Redis (sentinel mode): {}", url);
                url
            }
        };

        Client::open(connection_info)
    }

    #[allow(clippy::result_large_err)]
    fn render_command_template(
        &self,
        record: &StorageRecord,
        processed_data: &bytes::Bytes,
    ) -> Result<Vec<String>, CommonError> {
        let mut rendered = self.config.command_template.clone();

        let mut replacements = HashMap::new();
        replacements.insert("client_id", record.metadata.key.clone().unwrap_or_default());
        replacements.insert("topic", record.metadata.shard.clone());
        replacements.insert(
            "payload",
            String::from_utf8_lossy(processed_data).to_string(),
        );
        replacements.insert("timestamp", record.metadata.create_t.to_string());
        replacements.insert("key", record.metadata.key.clone().unwrap_or_default());

        for (placeholder, value) in replacements.iter() {
            let pattern = format!("${{{}}}", placeholder);
            rendered = rendered.replace(&pattern, value);
        }

        let parts: Vec<String> = rendered.split_whitespace().map(|s| s.to_string()).collect();

        if parts.is_empty() {
            return Err(CommonError::CommonError(
                "Rendered command template is empty".to_string(),
            ));
        }

        Ok(parts)
    }
    async fn execute_command(
        &self,
        conn: &mut ConnectionManager,
        command_parts: Vec<String>,
    ) -> Result<(), RedisError> {
        if command_parts.is_empty() {
            return Ok(());
        }

        let mut cmd = Cmd::new();
        cmd.arg(&command_parts[0]);

        for arg in &command_parts[1..] {
            cmd.arg(arg);
        }

        cmd.query_async::<()>(conn).await?;
        Ok(())
    }
}

#[async_trait]
impl ConnectorSink for RedisBridgePlugin {
    type SinkResource = ConnectionManager;

    async fn validate(&self) -> Result<(), CommonError> {
        self.config.validate()?;

        Ok(())
    }

    async fn init_sink(&self) -> Result<Self::SinkResource, CommonError> {
        let client = self.build_redis_client().map_err(|e| {
            CommonError::CommonError(format!("Failed to build Redis client: {}", e))
        })?;

        let conn_manager = ConnectionManager::new(client).await.map_err(|e| {
            CommonError::CommonError(format!("Failed to create Redis connection manager: {}", e))
        })?;

        info!(
            "Redis connection manager initialized successfully: server={}, mode={:?}",
            self.config.server, self.config.mode
        );

        Ok(conn_manager)
    }

    async fn send_batch(
        &self,
        records: &[StorageRecord],
        conn: &mut ConnectionManager,
    ) -> Result<Vec<FailureRecordInfo>, CommonError> {
        let mut success_count = 0;
        let mut error_count = 0;
        let mut fail_messages = Vec::new();

        for record in records {
            let processed_data =
                match apply_rule_engine(&self.connector.etl_rule, &record.data).await {
                    Ok(data) => data,
                    Err(e) => {
                        error!("Failed to apply rule before Redis send: {}", e);
                        error_count += 1;
                        fail_messages.push(FailureRecordInfo {
                            tenant: self.connector.tenant.clone(),
                            connector_name: self.connector.connector_name.clone(),
                            connector_type: self.connector.connector_type.to_string(),
                            source_topic: self.connector.topic_name.clone(),
                            error_message: e.to_string(),
                            records: vec![record.clone()],
                        });
                        continue;
                    }
                };

            let command_parts = match self.render_command_template(record, &processed_data) {
                Ok(parts) => parts,
                Err(e) => {
                    error!("Failed to render command template: {}", e);
                    error_count += 1;
                    fail_messages.push(FailureRecordInfo {
                        tenant: self.connector.tenant.clone(),
                        connector_name: self.connector.connector_name.clone(),
                        connector_type: self.connector.connector_type.to_string(),
                        source_topic: self.connector.topic_name.clone(),
                        error_message: e.to_string(),
                        records: vec![record.clone()],
                    });
                    continue;
                }
            };

            let mut retry_count = 0;
            let mut last_error = None;

            while retry_count <= self.config.max_retries {
                match self.execute_command(conn, command_parts.clone()).await {
                    Ok(_) => {
                        success_count += 1;
                        break;
                    }
                    Err(e) => {
                        last_error = Some(e);
                        retry_count += 1;

                        if retry_count <= self.config.max_retries {
                            warn!(
                                "Redis command failed, retrying ({}/{}): {}",
                                retry_count,
                                self.config.max_retries,
                                last_error.as_ref().unwrap()
                            );
                            tokio::time::sleep(Duration::from_millis(
                                self.config.retry_interval_ms,
                            ))
                            .await;
                        }
                    }
                }
            }

            if retry_count > self.config.max_retries {
                let err_msg = last_error
                    .as_ref()
                    .map(ToString::to_string)
                    .unwrap_or_else(|| "unknown redis command error".to_string());
                error!(
                    "Redis command failed after {} retries: {}",
                    self.config.max_retries, err_msg
                );
                error_count += 1;
                fail_messages.push(FailureRecordInfo {
                    tenant: self.connector.tenant.clone(),
                    connector_name: self.connector.connector_name.clone(),
                    connector_type: self.connector.connector_type.to_string(),
                    source_topic: self.connector.topic_name.clone(),
                    error_message: err_msg,
                    records: vec![record.clone()],
                });
            }
        }

        info!(
            "Redis batch send completed: success={}, errors={}",
            success_count, error_count
        );

        if error_count == records.len() && !records.is_empty() {
            return Err(CommonError::CommonError(
                "All records failed to send to Redis".to_string(),
            ));
        }

        Ok(fail_messages)
    }

    async fn cleanup_sink(&self, _conn: ConnectionManager) -> Result<(), CommonError> {
        info!("Redis connection manager cleanup completed");
        Ok(())
    }
}

pub fn start_redis_connector(
    client_pool: Arc<ClientPool>,
    connector_manager: Arc<ConnectorManager>,
    storage_driver_manager: Arc<StorageDriverManager>,
    connector: MQTTConnector,
    thread: BridgePluginThread,
    stop_recv: Receiver<bool>,
) {
    tokio::spawn(Box::pin(async move {
        let connector_name = connector.connector_name.clone();
        let connector_type = connector.connector_type.to_string();
        let bridge = match RedisBridgePlugin::new(connector.clone()) {
            Ok(bridge) => bridge,
            Err(e) => {
                error!(
                    "Invalid connector config type for Redis connector, connector_name='{}', connector_type='{}', error={}",
                    connector_name, connector_type, e
                );
                return;
            }
        };
        connector_manager.add_connector_thread(
            &connector.tenant,
            &connector.connector_name,
            thread,
        );

        if let Err(e) = run_connector_loop(
            &bridge,
            &client_pool,
            &connector_manager,
            &storage_driver_manager,
            connector.connector_name.clone(),
            BridgePluginReadConfig {
                tenant: connector.tenant,
                topic_name: connector.topic_name,
                record_num: 100,
                strategy: connector.failure_strategy,
            },
            stop_recv,
        )
        .await
        {
            error!(
                "Redis connector loop error, connector_name='{}', connector_type='{}', error={}",
                connector_name, connector_type, e
            );
        }
    }));
}
