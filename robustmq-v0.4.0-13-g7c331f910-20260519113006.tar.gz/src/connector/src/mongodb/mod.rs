// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::sync::Arc;
use std::time::Duration;

use async_trait::async_trait;
use bson::Document;
use grpc_clients::pool::ClientPool;
use metadata_struct::{
    connector::config_mongodb::MongoDBConnectorConfig, connector::MQTTConnector,
    storage::record::StorageRecord,
};
use mongodb::{
    options::{ClientOptions, InsertManyOptions, WriteConcern},
    Client, Collection,
};
use rule_engine::apply_rule_engine;
use storage_adapter::driver::StorageDriverManager;
use tokio::sync::mpsc::Receiver;
use tracing::{debug, error, info, warn};

use common_base::error::common::CommonError;

use super::{
    core::{BridgePluginReadConfig, BridgePluginThread},
    failure::FailureRecordInfo,
    loops::run_connector_loop,
    manager::ConnectorManager,
    traits::ConnectorSink,
};

pub struct MongoDBBridgePlugin {
    connector: MQTTConnector,
    config: MongoDBConnectorConfig,
}

impl MongoDBBridgePlugin {
    #[allow(clippy::result_large_err)]
    pub fn new(connector: MQTTConnector) -> Result<Self, CommonError> {
        let config = match &connector.connector_type {
            metadata_struct::connector::ConnectorType::MongoDB(config) => config.clone(),
            _ => {
                return Err(CommonError::CommonError(
                    "invalid connector type for mongodb plugin".to_string(),
                ));
            }
        };
        Ok(MongoDBBridgePlugin { connector, config })
    }

    async fn create_client(&self) -> Result<Client, CommonError> {
        let uri = self.config.build_connection_uri();
        debug!("Connecting to MongoDB at {}", self.config.host);

        let mut client_options = ClientOptions::parse(&uri).await.map_err(|e| {
            CommonError::CommonError(format!(
                "Failed to parse MongoDB URI for {}: {}",
                self.config.host, e
            ))
        })?;

        client_options.connect_timeout =
            Some(Duration::from_secs(self.config.connect_timeout_secs));
        client_options.server_selection_timeout = Some(Duration::from_secs(
            self.config.server_selection_timeout_secs,
        ));

        if let Some(max_pool) = self.config.max_pool_size {
            client_options.max_pool_size = Some(max_pool);
        }
        if let Some(min_pool) = self.config.min_pool_size {
            client_options.min_pool_size = Some(min_pool);
        }

        let w_value = if self.config.w == "majority" {
            WriteConcern::builder()
                .w(mongodb::options::Acknowledgment::Majority)
                .build()
        } else if let Ok(w_num) = self.config.w.parse::<u32>() {
            WriteConcern::builder()
                .w(mongodb::options::Acknowledgment::Nodes(w_num))
                .build()
        } else {
            WriteConcern::builder()
                .w(mongodb::options::Acknowledgment::Nodes(1))
                .build()
        };
        client_options.write_concern = Some(w_value);

        Client::with_options(client_options).map_err(|e| {
            CommonError::CommonError(format!(
                "Failed to create MongoDB client for {}:{}: {}",
                self.config.host, self.config.port, e
            ))
        })
    }

    #[allow(clippy::result_large_err)]
    async fn record_to_document(&self, record: &StorageRecord) -> Result<Document, CommonError> {
        let processed_data = apply_rule_engine(&self.connector.etl_rule, &record.data).await?;
        let mut processed_record = record.clone();
        processed_record.data = processed_data;
        bson::to_document(&processed_record).map_err(|e| {
            CommonError::CommonError(format!(
                "Failed to serialize record with key '{:?}' at timestamp {}: {}",
                processed_record.metadata.key, processed_record.metadata.create_t, e
            ))
        })
    }
}

#[async_trait]
impl ConnectorSink for MongoDBBridgePlugin {
    type SinkResource = Collection<Document>;

    async fn validate(&self) -> Result<(), CommonError> {
        info!(
            "Validating MongoDB connector configuration for {}:{}",
            self.config.host, self.config.port
        );

        let client = self.create_client().await?;

        let db = client.database(&self.config.database);

        match tokio::time::timeout(
            Duration::from_secs(self.config.server_selection_timeout_secs),
            db.run_command(bson::doc! { "ping": 1 }, None),
        )
        .await
        {
            Ok(Ok(_)) => {
                info!(
                    "Successfully validated MongoDB connection to {}:{}/{}",
                    self.config.host, self.config.port, self.config.database
                );
                Ok(())
            }
            Ok(Err(e)) => Err(CommonError::CommonError(format!(
                "MongoDB ping failed for {}:{}/{}: {}",
                self.config.host, self.config.port, self.config.database, e
            ))),
            Err(_) => Err(CommonError::CommonError(format!(
                "MongoDB ping timeout for {}:{}/{}",
                self.config.host, self.config.port, self.config.database
            ))),
        }
    }

    async fn init_sink(&self) -> Result<Self::SinkResource, CommonError> {
        info!(
            "Initializing MongoDB sink: {}:{}/{}/{}",
            self.config.host, self.config.port, self.config.database, self.config.collection
        );
        let client = self.create_client().await?;
        let db = client.database(&self.config.database);
        let collection = db.collection(&self.config.collection);
        info!("MongoDB sink initialized successfully");
        Ok(collection)
    }

    async fn send_batch(
        &self,
        records: &[StorageRecord],
        collection: &mut Collection<Document>,
    ) -> Result<Vec<FailureRecordInfo>, CommonError> {
        if records.is_empty() {
            return Ok(vec![]);
        }

        debug!("Processing batch of {} records for MongoDB", records.len());

        let mut documents = Vec::with_capacity(records.len());
        let mut failed_serializations = Vec::new();
        let mut fail_messages = Vec::new();

        for (idx, record) in records.iter().enumerate() {
            match self.record_to_document(record).await {
                Ok(doc) => documents.push(doc),
                Err(e) => {
                    warn!(
                        "Failed to serialize record {}/{} (key: '{:?}', timestamp: {}): {}",
                        idx + 1,
                        records.len(),
                        record.metadata.key,
                        record.metadata.create_t,
                        e
                    );
                    failed_serializations.push((idx, e.to_string()));
                    fail_messages.push(FailureRecordInfo {
                        tenant: self.connector.tenant.clone(),
                        connector_name: self.connector.connector_name.clone(),
                        connector_type: self.connector.connector_type.to_string(),
                        source_topic: self.connector.topic_name.clone(),
                        error_message: e.to_string(),
                        records: vec![record.clone()],
                    });
                }
            }
        }

        if documents.is_empty() {
            return Ok(fail_messages);
        }

        if !failed_serializations.is_empty() {
            warn!(
                "{}/{} records failed serialization and will not be inserted",
                failed_serializations.len(),
                records.len()
            );
        }

        let options = InsertManyOptions::builder()
            .ordered(self.config.ordered_insert)
            .build();

        debug!(
            "Inserting {} documents into MongoDB (ordered={})",
            documents.len(),
            self.config.ordered_insert
        );

        match collection.insert_many(documents, options).await {
            Ok(result) => {
                info!(
                    "Successfully inserted {} documents into {}.{}",
                    result.inserted_ids.len(),
                    self.config.database,
                    self.config.collection
                );
                Ok(fail_messages)
            }
            Err(e) => {
                let error_msg = format!(
                    "Failed to insert documents into {}.{}: {}",
                    self.config.database, self.config.collection, e
                );
                error!("{}", error_msg);
                Err(CommonError::CommonError(error_msg))
            }
        }
    }
}

pub fn start_mongodb_connector(
    client_pool: Arc<ClientPool>,
    connector_manager: Arc<ConnectorManager>,
    storage_driver_manager: Arc<StorageDriverManager>,
    connector: MQTTConnector,
    thread: BridgePluginThread,
    stop_recv: Receiver<bool>,
) {
    tokio::spawn(Box::pin(async move {
        let connector_name = connector.connector_name.clone();
        let connector_type = connector.connector_type.to_string();
        let bridge = match MongoDBBridgePlugin::new(connector.clone()) {
            Ok(bridge) => bridge,
            Err(e) => {
                error!(
                    "Invalid connector config type for MongoDB connector, connector_name='{}', connector_type='{}', error={}",
                    connector_name, connector_type, e
                );
                return;
            }
        };
        let batch_size = bridge.config.batch_size as u64;

        connector_manager.add_connector_thread(
            &connector.tenant,
            &connector.connector_name,
            thread,
        );

        if let Err(e) = run_connector_loop(
            &bridge,
            &client_pool,
            &connector_manager,
            &storage_driver_manager,
            connector.connector_name.clone(),
            BridgePluginReadConfig {
                tenant: connector.tenant,
                topic_name: connector.topic_name,
                record_num: batch_size,
                strategy: connector.failure_strategy,
            },
            stop_recv,
        )
        .await
        {
            connector_manager.remove_connector_thread(&connector.connector_name);
            error!(
                "Failed to start MongoDBBridgePlugin, connector_name='{}', connector_type='{}', error={:?}",
                connector_name, connector_type, e
            );
        }
    }));
}
