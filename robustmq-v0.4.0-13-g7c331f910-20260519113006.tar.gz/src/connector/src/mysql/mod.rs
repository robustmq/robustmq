// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::sync::Arc;

use async_trait::async_trait;
use grpc_clients::pool::ClientPool;
use metadata_struct::{
    connector::config_mysql::MySQLConnectorConfig, connector::MQTTConnector,
    storage::record::StorageRecord,
};
use rule_engine::apply_rule_engine;
use sqlx::{mysql::MySqlPoolOptions, MySql, Pool};
use storage_adapter::driver::StorageDriverManager;
use tokio::sync::mpsc::Receiver;
use tracing::{error, warn};

use common_base::error::common::CommonError;

use super::{
    core::{BridgePluginReadConfig, BridgePluginThread},
    failure::FailureRecordInfo,
    loops::run_connector_loop,
    manager::ConnectorManager,
    traits::ConnectorSink,
};

pub struct MySQLBridgePlugin {
    connector: MQTTConnector,
    config: MySQLConnectorConfig,
}

impl MySQLBridgePlugin {
    #[allow(clippy::result_large_err)]
    pub fn new(connector: MQTTConnector) -> Result<Self, CommonError> {
        let config = match &connector.connector_type {
            metadata_struct::connector::ConnectorType::MySQL(config) => config.clone(),
            _ => {
                return Err(CommonError::CommonError(
                    "invalid connector type for mysql plugin".to_string(),
                ));
            }
        };
        Ok(MySQLBridgePlugin { connector, config })
    }

    async fn create_pool(&self) -> Result<Pool<MySql>, sqlx::Error> {
        MySqlPoolOptions::new()
            .max_connections(self.config.get_pool_size())
            .connect(&self.config.connection_url())
            .await
    }

    async fn single_insert(
        &self,
        records: &[StorageRecord],
        pool: &Pool<MySql>,
    ) -> Result<(), CommonError> {
        for record in records {
            let payload = serde_json::to_string(record)?;

            let base_sql = if let Some(template) = &self.config.sql_template {
                let placeholder_count = template.matches('?').count();
                if placeholder_count != 3 {
                    warn!(
                        "sql_template expects 3 placeholders, but found {}. Using provided template with binds (key, payload, timestamp) in order.",
                        placeholder_count
                    );
                }
                template.clone()
            } else {
                format!(
                    "INSERT INTO {} (record_key, payload, timestamp) VALUES (?, ?, ?)",
                    self.config.table
                )
            };

            let sql = if self.config.is_upsert_enabled() {
                format!(
                    "{} ON DUPLICATE KEY UPDATE payload = VALUES(payload), timestamp = VALUES(timestamp)",
                    base_sql
                )
            } else {
                base_sql
            };

            sqlx::query(&sql)
                .bind(&record.metadata.key)
                .bind(&payload)
                .bind(record.metadata.create_t as i64)
                .execute(pool)
                .await?;
        }

        Ok(())
    }

    async fn batch_insert(
        &self,
        records: &[StorageRecord],
        pool: &Pool<MySql>,
    ) -> Result<(), CommonError> {
        let mut values_placeholders = Vec::with_capacity(records.len());
        let mut bindings = Vec::with_capacity(records.len());

        for record in records {
            values_placeholders.push("(?, ?, ?)");
            let payload = serde_json::to_string(record)?;
            bindings.push((
                record.metadata.key.clone(),
                payload,
                record.metadata.create_t as i64,
            ));
        }

        let base_sql = format!(
            "INSERT INTO {} (record_key, payload, timestamp) VALUES {}",
            self.config.table,
            values_placeholders.join(", ")
        );

        let sql = if self.config.is_upsert_enabled() {
            format!(
                "{} ON DUPLICATE KEY UPDATE payload = VALUES(payload), timestamp = VALUES(timestamp)",
                base_sql
            )
        } else {
            base_sql
        };

        let mut query = sqlx::query(&sql);
        for (key, payload, timestamp) in bindings {
            query = query.bind(key).bind(payload).bind(timestamp);
        }

        query.execute(pool).await?;

        Ok(())
    }
}

#[async_trait]
impl ConnectorSink for MySQLBridgePlugin {
    type SinkResource = Pool<MySql>;

    async fn validate(&self) -> Result<(), CommonError> {
        Ok(())
    }

    async fn init_sink(&self) -> Result<Self::SinkResource, CommonError> {
        let pool = self.create_pool().await?;
        Ok(pool)
    }

    async fn send_batch(
        &self,
        records: &[StorageRecord],
        pool: &mut Pool<MySql>,
    ) -> Result<Vec<FailureRecordInfo>, CommonError> {
        if records.is_empty() {
            return Ok(vec![]);
        }
        let mut processed_records = Vec::with_capacity(records.len());
        let mut fail_messages = Vec::new();
        for record in records {
            let processed_data =
                match apply_rule_engine(&self.connector.etl_rule, &record.data).await {
                    Ok(data) => data,
                    Err(e) => {
                        fail_messages.push(FailureRecordInfo {
                            tenant: self.connector.tenant.clone(),
                            connector_name: self.connector.connector_name.clone(),
                            connector_type: self.connector.connector_type.to_string(),
                            source_topic: self.connector.topic_name.clone(),
                            error_message: e.to_string(),
                            records: vec![record.clone()],
                        });
                        continue;
                    }
                };
            let mut processed_record = record.clone();
            processed_record.data = processed_data;
            processed_records.push(processed_record);
        }
        if processed_records.is_empty() {
            return Ok(fail_messages);
        }
        if self.config.is_batch_insert_enabled() {
            if self.config.sql_template.is_some() {
                warn!(
                    "sql_template is not applied in batch mode; default batch INSERT will be used"
                );
            }
            self.batch_insert(&processed_records, pool).await?;
        } else {
            self.single_insert(&processed_records, pool).await?;
        }
        Ok(fail_messages)
    }

    async fn cleanup_sink(&self, pool: Pool<MySql>) -> Result<(), CommonError> {
        pool.close().await;
        Ok(())
    }
}

pub fn start_mysql_connector(
    client_pool: Arc<ClientPool>,
    connector_manager: Arc<ConnectorManager>,
    storage_driver_manager: Arc<StorageDriverManager>,
    connector: MQTTConnector,
    thread: BridgePluginThread,
    stop_recv: Receiver<bool>,
) {
    tokio::spawn(Box::pin(async move {
        let connector_name = connector.connector_name.clone();
        let connector_type = connector.connector_type.to_string();
        let bridge = match MySQLBridgePlugin::new(connector.clone()) {
            Ok(bridge) => bridge,
            Err(e) => {
                error!(
                    "Invalid connector config type for MySQL connector, connector_name='{}', connector_type='{}', error={}",
                    connector_name, connector_type, e
                );
                return;
            }
        };
        connector_manager.add_connector_thread(
            &connector.tenant,
            &connector.connector_name,
            thread,
        );

        if let Err(e) = run_connector_loop(
            &bridge,
            &client_pool,
            &connector_manager,
            &storage_driver_manager,
            connector.connector_name.clone(),
            BridgePluginReadConfig {
                tenant: connector.tenant,
                topic_name: connector.topic_name,
                record_num: 100,
                strategy: connector.failure_strategy,
            },
            stop_recv,
        )
        .await
        {
            connector_manager.remove_connector_thread(&connector.connector_name);
            error!(
                "Failed to start MySQLBridgePlugin, connector_name='{}', connector_type='{}', error={:?}",
                connector_name, connector_type, e
            );
        }
    }));
}
