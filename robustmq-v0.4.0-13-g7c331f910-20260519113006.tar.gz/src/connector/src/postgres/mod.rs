// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::sync::Arc;

use async_trait::async_trait;
use grpc_clients::pool::ClientPool;
use metadata_struct::{
    connector::config_postgres::PostgresConnectorConfig, connector::MQTTConnector,
    storage::record::StorageRecord,
};
use rule_engine::apply_rule_engine;
use sqlx::{postgres::PgPoolOptions, Pool, Postgres};
use storage_adapter::driver::StorageDriverManager;
use tokio::sync::mpsc::Receiver;
use tracing::{error, warn};

use common_base::error::common::CommonError;

use super::{
    core::{BridgePluginReadConfig, BridgePluginThread},
    failure::FailureRecordInfo,
    loops::run_connector_loop,
    manager::ConnectorManager,
    traits::ConnectorSink,
};

pub struct PostgresBridgePlugin {
    connector: MQTTConnector,
    config: PostgresConnectorConfig,
}

impl PostgresBridgePlugin {
    #[allow(clippy::result_large_err)]
    pub fn new(connector: MQTTConnector) -> Result<Self, CommonError> {
        let config = match &connector.connector_type {
            metadata_struct::connector::ConnectorType::Postgres(config) => config.clone(),
            _ => {
                return Err(CommonError::CommonError(
                    "invalid connector type for postgres plugin".to_string(),
                ));
            }
        };
        Ok(PostgresBridgePlugin { connector, config })
    }

    async fn create_pool(&self) -> Result<Pool<Postgres>, sqlx::Error> {
        PgPoolOptions::new()
            .max_connections(self.config.get_pool_size())
            .connect(&self.config.connection_url())
            .await
    }

    async fn single_insert(
        &self,
        records: &[StorageRecord],
        pool: &Pool<Postgres>,
    ) -> Result<(), CommonError> {
        for record in records {
            let client_id = &record.metadata.key;
            let timestamp = record.metadata.create_t as i64;
            let topic = record
                .metadata
                .header
                .as_ref()
                .and_then(|headers| headers.iter().find(|h| h.name == "topic"))
                .map(|h| h.value.clone())
                .unwrap_or_else(|| "unknown".to_string());
            let payload_str = String::from_utf8_lossy(&record.data).to_string();

            let base_sql = if let Some(template) = &self.config.sql_template {
                let placeholder_count = (1..=10)
                    .filter(|i| template.contains(&format!("${}", i)))
                    .count();
                if placeholder_count != 5 {
                    warn!(
                        "sql_template expects 5 placeholders, but found {}. Using provided template with binds (client_id, topic, timestamp, payload, data) in order.",
                        placeholder_count
                    );
                }
                template.clone()
            } else {
                format!(
                    "INSERT INTO {} (client_id, topic, timestamp, payload, data) VALUES ($1, $2, $3, $4, $5)",
                    self.config.table
                )
            };

            let sql = if self.config.is_upsert_enabled() {
                let conflict_columns = self
                    .config
                    .conflict_columns
                    .as_deref()
                    .unwrap_or("client_id, topic");

                format!(
                    "{} ON CONFLICT ({}) DO UPDATE SET timestamp = EXCLUDED.timestamp, payload = EXCLUDED.payload, data = EXCLUDED.data",
                    base_sql, conflict_columns
                )
            } else {
                base_sql
            };

            sqlx::query(&sql)
                .bind(client_id)
                .bind(&topic)
                .bind(timestamp)
                .bind(&payload_str)
                .bind(record.data.as_ref())
                .execute(pool)
                .await?;
        }

        Ok(())
    }

    async fn batch_insert(
        &self,
        records: &[StorageRecord],
        pool: &Pool<Postgres>,
    ) -> Result<(), CommonError> {
        let mut value_placeholders = Vec::with_capacity(records.len());
        let mut param_index = 1;

        let mut client_ids = Vec::with_capacity(records.len());
        let mut topics = Vec::with_capacity(records.len());
        let mut timestamps = Vec::with_capacity(records.len());
        let mut payloads = Vec::with_capacity(records.len());
        let mut data_vec = Vec::with_capacity(records.len());

        for record in records {
            let client_id = record.metadata.key.clone();
            let timestamp = record.metadata.create_t as i64;
            let topic = record
                .metadata
                .header
                .as_ref()
                .and_then(|headers| headers.iter().find(|h| h.name == "topic"))
                .map(|h| h.value.clone())
                .unwrap_or_else(|| "unknown".to_string());
            let payload_str = String::from_utf8_lossy(&record.data).to_string();
            let data = record.data.clone();

            client_ids.push(client_id);
            topics.push(topic);
            timestamps.push(timestamp);
            payloads.push(payload_str);
            data_vec.push(data);

            value_placeholders.push(format!(
                "(${}, ${}, ${}, ${}, ${})",
                param_index,
                param_index + 1,
                param_index + 2,
                param_index + 3,
                param_index + 4
            ));
            param_index += 5;
        }

        let base_sql = format!(
            "INSERT INTO {} (client_id, topic, timestamp, payload, data) VALUES {}",
            self.config.table,
            value_placeholders.join(", ")
        );

        let sql = if self.config.is_upsert_enabled() {
            let conflict_columns = self
                .config
                .conflict_columns
                .as_deref()
                .unwrap_or("client_id, topic");

            format!(
                "{} ON CONFLICT ({}) DO UPDATE SET timestamp = EXCLUDED.timestamp, payload = EXCLUDED.payload, data = EXCLUDED.data",
                base_sql, conflict_columns
            )
        } else {
            base_sql
        };

        let mut query = sqlx::query(&sql);
        for i in 0..records.len() {
            query = query
                .bind(&client_ids[i])
                .bind(&topics[i])
                .bind(timestamps[i])
                .bind(&payloads[i])
                .bind(data_vec[i].as_ref());
        }

        query.execute(pool).await?;

        Ok(())
    }
}

#[async_trait]
impl ConnectorSink for PostgresBridgePlugin {
    type SinkResource = Pool<Postgres>;

    async fn validate(&self) -> Result<(), CommonError> {
        Ok(())
    }

    async fn init_sink(&self) -> Result<Self::SinkResource, CommonError> {
        let pool = self.create_pool().await?;
        Ok(pool)
    }

    async fn send_batch(
        &self,
        records: &[StorageRecord],
        pool: &mut Pool<Postgres>,
    ) -> Result<Vec<FailureRecordInfo>, CommonError> {
        if records.is_empty() {
            return Ok(vec![]);
        }

        let mut processed_records = Vec::with_capacity(records.len());
        let mut fail_messages = Vec::new();
        for record in records {
            let processed_data =
                match apply_rule_engine(&self.connector.etl_rule, &record.data).await {
                    Ok(data) => data,
                    Err(e) => {
                        fail_messages.push(FailureRecordInfo {
                            tenant: self.connector.tenant.clone(),
                            connector_name: self.connector.connector_name.clone(),
                            connector_type: self.connector.connector_type.to_string(),
                            source_topic: self.connector.topic_name.clone(),
                            error_message: e.to_string(),
                            records: vec![record.clone()],
                        });
                        continue;
                    }
                };
            let mut processed_record = record.clone();
            processed_record.data = processed_data;
            processed_records.push(processed_record);
        }

        if processed_records.is_empty() {
            return Ok(fail_messages);
        }

        if self.config.is_batch_insert_enabled() {
            if self.config.sql_template.is_some() {
                warn!(
                    "sql_template is not applied in batch mode; default batch INSERT will be used"
                );
            }
            self.batch_insert(&processed_records, pool).await?;
        } else {
            self.single_insert(&processed_records, pool).await?;
        }
        Ok(fail_messages)
    }

    async fn cleanup_sink(&self, pool: Pool<Postgres>) -> Result<(), CommonError> {
        pool.close().await;
        Ok(())
    }
}

pub fn start_postgres_connector(
    client_pool: Arc<ClientPool>,
    connector_manager: Arc<ConnectorManager>,
    storage_driver_manager: Arc<StorageDriverManager>,
    connector: MQTTConnector,
    thread: BridgePluginThread,
    stop_recv: Receiver<bool>,
) {
    tokio::spawn(Box::pin(async move {
        let connector_name = connector.connector_name.clone();
        let connector_type = connector.connector_type.to_string();
        let bridge = match PostgresBridgePlugin::new(connector.clone()) {
            Ok(bridge) => bridge,
            Err(e) => {
                error!(
                    "Invalid connector config type for Postgres connector, connector_name='{}', connector_type='{}', error={}",
                    connector_name, connector_type, e
                );
                return;
            }
        };
        connector_manager.add_connector_thread(
            &connector.tenant,
            &connector.connector_name,
            thread,
        );

        if let Err(e) = run_connector_loop(
            &bridge,
            &client_pool,
            &connector_manager,
            &storage_driver_manager,
            connector.connector_name.clone(),
            BridgePluginReadConfig {
                tenant: connector.tenant,
                topic_name: connector.topic_name,
                record_num: 100,
                strategy: connector.failure_strategy,
            },
            stop_recv,
        )
        .await
        {
            connector_manager.remove_connector_thread(&connector.connector_name);
            error!(
                "Failed to start PostgresBridgePlugin, connector_name='{}', connector_type='{}', error={:?}",
                connector_name, connector_type, e
            );
        }
    }));
}
