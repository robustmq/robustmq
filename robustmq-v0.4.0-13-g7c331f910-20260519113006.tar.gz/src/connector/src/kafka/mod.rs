// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::{sync::Arc, time::Duration};

use super::{
    core::{BridgePluginReadConfig, BridgePluginThread},
    failure::FailureRecordInfo,
    loops::run_connector_loop,
    manager::ConnectorManager,
    traits::ConnectorSink,
};
use async_trait::async_trait;
use common_base::error::common::CommonError;
use grpc_clients::pool::ClientPool;
use metadata_struct::{
    connector::config_kafka::KafkaConnectorConfig, connector::MQTTConnector,
    storage::record::StorageRecord,
};
use rdkafka::producer::{FutureProducer, FutureRecord, Producer};
use rule_engine::apply_rule_engine;
use storage_adapter::driver::StorageDriverManager;
use tokio::sync::mpsc::Receiver;
use tracing::error;

pub struct KafkaBridgePlugin {
    connector: MQTTConnector,
    config: KafkaConnectorConfig,
}

impl KafkaBridgePlugin {
    #[allow(clippy::result_large_err)]
    pub fn new(connector: MQTTConnector) -> Result<Self, CommonError> {
        let config = match &connector.connector_type {
            metadata_struct::connector::ConnectorType::Kafka(config) => config.clone(),
            _ => {
                return Err(CommonError::CommonError(
                    "invalid connector type for kafka plugin".to_string(),
                ));
            }
        };
        Ok(KafkaBridgePlugin { connector, config })
    }
}

#[async_trait]
impl ConnectorSink for KafkaBridgePlugin {
    type SinkResource = FutureProducer;

    async fn validate(&self) -> Result<(), CommonError> {
        Ok(())
    }

    async fn init_sink(&self) -> Result<Self::SinkResource, CommonError> {
        use tracing::info;

        let mut client_config = rdkafka::ClientConfig::new();

        client_config
            .set("bootstrap.servers", &self.config.bootstrap_servers)
            .set(
                "message.timeout.ms",
                self.config.message_timeout_ms.to_string(),
            )
            .set("compression.type", &self.config.compression_type)
            .set("batch.size", self.config.batch_size.to_string())
            .set("linger.ms", self.config.linger_ms.to_string())
            .set("acks", &self.config.acks)
            .set("retries", self.config.retries.to_string())
            .set("queue.buffering.max.messages", "100000")
            .set("queue.buffering.max.kbytes", "1048576");

        info!(
            "Kafka producer initialized: servers={}, topic={}, compression={}, batch_size={}, acks={}",
            self.config.bootstrap_servers,
            self.config.topic,
            self.config.compression_type,
            self.config.batch_size,
            self.config.acks
        );

        let producer: FutureProducer = client_config.create()?;
        Ok(producer)
    }

    async fn send_batch(
        &self,
        records: &[StorageRecord],
        producer: &mut FutureProducer,
    ) -> Result<Vec<FailureRecordInfo>, CommonError> {
        use futures::future::join_all;

        let mut processed_records = Vec::with_capacity(records.len());
        let mut fail_messages = Vec::new();
        for record in records {
            match apply_rule_engine(&self.connector.etl_rule, &record.data).await {
                Ok(data) => {
                    let mut processed_record = record.clone();
                    processed_record.data = data;
                    processed_records.push(processed_record);
                }
                Err(e) => {
                    tracing::error!("Failed to apply rule before Kafka send: {}", e);
                    fail_messages.push(FailureRecordInfo {
                        tenant: self.connector.tenant.clone(),
                        connector_name: self.connector.connector_name.clone(),
                        connector_type: self.connector.connector_type.to_string(),
                        source_topic: self.connector.topic_name.clone(),
                        error_message: e.to_string(),
                        records: vec![record.clone()],
                    });
                }
            }
        }

        if processed_records.is_empty() {
            return Ok(fail_messages);
        }

        let mut serialized_data = Vec::with_capacity(records.len());
        let mut keys = Vec::with_capacity(records.len());

        for record in &processed_records {
            let data = serde_json::to_string(record)?;
            serialized_data.push(data);

            let key = if self.config.key.is_empty() {
                record.metadata.key.clone().unwrap_or_default()
            } else {
                self.config.key.clone()
            };
            keys.push(key);
        }

        let mut send_futures = Vec::with_capacity(serialized_data.len());

        for (data, key) in serialized_data.iter().zip(keys.iter()) {
            let future = producer.send(
                FutureRecord::to(self.config.topic.as_str())
                    .key(key)
                    .payload(data),
                Duration::from_secs(0),
            );
            send_futures.push(future);
        }

        let results = join_all(send_futures).await;

        if results.iter().any(|r| r.is_err()) {
            return Err(CommonError::CommonError(
                "One or more records failed to send to Kafka".to_string(),
            ));
        }

        Ok(fail_messages)
    }

    async fn cleanup_sink(&self, producer: FutureProducer) -> Result<(), CommonError> {
        use tracing::info;

        info!(
            "Flushing Kafka producer with timeout of {}s",
            self.config.cleanup_timeout_secs
        );
        producer.flush(Duration::from_secs(self.config.cleanup_timeout_secs))?;
        Ok(())
    }
}

pub fn start_kafka_connector(
    client_pool: Arc<ClientPool>,
    connector_manager: Arc<ConnectorManager>,
    storage_driver_manager: Arc<StorageDriverManager>,
    connector: MQTTConnector,
    thread: BridgePluginThread,
    stop_recv: Receiver<bool>,
) {
    tokio::spawn(Box::pin(async move {
        let connector_name = connector.connector_name.clone();
        let connector_type = connector.connector_type.to_string();
        let bridge = match KafkaBridgePlugin::new(connector.clone()) {
            Ok(bridge) => bridge,
            Err(e) => {
                error!(
                    "Invalid connector config type for Kafka connector, connector_name='{}', connector_type='{}', error={}",
                    connector_name, connector_type, e
                );
                return;
            }
        };
        connector_manager.add_connector_thread(
            &connector.tenant,
            &connector.connector_name,
            thread,
        );

        if let Err(e) = run_connector_loop(
            &bridge,
            &client_pool,
            &connector_manager,
            &storage_driver_manager,
            connector.connector_name.clone(),
            BridgePluginReadConfig {
                tenant: connector.tenant.clone(),
                topic_name: connector.topic_name.clone(),
                record_num: 100,
                strategy: connector.failure_strategy.clone(),
            },
            stop_recv,
        )
        .await
        {
            connector_manager.remove_connector_thread(&connector.connector_name);
            error!(
                "Failed to start KafkaBridgePlugin, connector='{:#?}', error={:?}",
                connector, e
            );
        }
    }));
}
