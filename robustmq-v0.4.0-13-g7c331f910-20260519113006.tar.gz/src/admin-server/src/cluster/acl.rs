// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use crate::{
    state::HttpState,
    tool::extractor::ValidatedJson,
    tool::{
        query::{apply_pagination, apply_sorting, build_query_params, Queryable},
        PageReplyData,
    },
};
use axum::extract::{Query, State};
use serde::{Deserialize, Serialize};
use validator::Validate;

#[derive(Serialize, Deserialize, Debug)]
pub struct AclListReq {
    pub tenant: Option<String>,
    pub name: Option<String>,
    pub resource_name: Option<String>,
    pub limit: Option<u32>,
    pub page: Option<u32>,
    pub sort_field: Option<String>,
    pub sort_by: Option<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq, Validate)]
pub struct CreateAclReq {
    #[validate(length(min = 1, max = 64, message = "Tenant length must be between 1-64"))]
    pub tenant: String,

    #[validate(length(min = 1, max = 128, message = "Name length must be between 1-128"))]
    pub name: String,

    #[validate(length(max = 256, message = "Desc length cannot exceed 256"))]
    pub desc: Option<String>,

    #[validate(length(
        min = 1,
        max = 50,
        message = "Resource type length must be between 1-50"
    ))]
    #[validate(custom(function = "validate_acl_resource_type"))]
    pub resource_type: String,

    #[validate(length(
        min = 1,
        max = 256,
        message = "Resource name length must be between 1-256"
    ))]
    pub resource_name: String,

    #[validate(length(max = 256, message = "Topic length cannot exceed 256"))]
    pub topic: Option<String>,

    #[validate(length(max = 128, message = "IP length cannot exceed 128"))]
    pub ip: Option<String>,

    #[validate(length(min = 1, max = 50, message = "Action length must be between 1-50"))]
    #[validate(custom(function = "validate_acl_action"))]
    pub action: String,

    #[validate(length(min = 1, max = 50, message = "Permission length must be between 1-50"))]
    #[validate(custom(function = "validate_acl_permission"))]
    pub permission: String,
}

fn validate_acl_resource_type(resource_type: &str) -> Result<(), validator::ValidationError> {
    match resource_type {
        "ClientId" | "User" | "Ip" => Ok(()),
        _ => {
            let mut err = validator::ValidationError::new("invalid_acl_resource_type");
            err.message = Some(std::borrow::Cow::from(
                "Resource type must be ClientId, User or Ip",
            ));
            Err(err)
        }
    }
}

fn validate_acl_action(action: &str) -> Result<(), validator::ValidationError> {
    match action {
        "Publish" | "Subscribe" | "All" => Ok(()),
        _ => {
            let mut err = validator::ValidationError::new("invalid_acl_action");
            err.message = Some(std::borrow::Cow::from(
                "Action must be Publish, Subscribe or All",
            ));
            Err(err)
        }
    }
}

fn validate_acl_permission(permission: &str) -> Result<(), validator::ValidationError> {
    match permission {
        "Allow" | "Deny" => Ok(()),
        _ => {
            let mut err = validator::ValidationError::new("invalid_acl_permission");
            err.message = Some(std::borrow::Cow::from("Permission must be Allow or Deny"));
            Err(err)
        }
    }
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq, Validate)]
pub struct DeleteAclReq {
    #[validate(length(min = 1, max = 64, message = "Tenant length must be between 1-64"))]
    pub tenant: String,

    #[validate(length(min = 1, max = 128, message = "Name length must be between 1-128"))]
    pub name: String,
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct AclListRow {
    pub tenant: String,
    pub name: String,
    pub desc: String,
    pub resource_type: String,
    pub resource_name: String,
    pub topic: String,
    pub ip: String,
    pub action: String,
    pub permission: String,
}

use common_base::{
    error::{common::CommonError, ResultCommonError},
    http_response::{error_response, success_response},
};
use common_security::storage::acl::AclStorage;
use metadata_struct::auth::acl::{
    EnumAclAction, EnumAclPermission, EnumAclResourceType, SecurityAcl,
};
use std::{str::FromStr, sync::Arc};

pub async fn acl_list(
    State(state): State<Arc<HttpState>>,
    Query(params): Query<AclListReq>,
) -> String {
    let options = build_query_params(
        params.page,
        params.limit,
        params.sort_field,
        params.sort_by,
        None,
        None,
        None,
    );
    let data: Vec<SecurityAcl> = state.mqtt_context.security_manager.metadata.get_all_acl();

    let acls_list: Vec<AclListRow> = data
        .into_iter()
        .filter(|acl| {
            if let Some(ref tenant) = params.tenant {
                if !acl.tenant.contains(tenant.as_str()) {
                    return false;
                }
            }
            if let Some(ref name) = params.name {
                if !acl.name.contains(name.as_str()) {
                    return false;
                }
            }
            if let Some(ref resource_name) = params.resource_name {
                if !acl.resource_name.contains(resource_name.as_str()) {
                    return false;
                }
            }
            true
        })
        .map(|acl| AclListRow {
            tenant: acl.tenant.clone(),
            name: acl.name.clone(),
            desc: acl.desc.clone(),
            resource_type: acl.resource_type.to_string(),
            resource_name: acl.resource_name.to_string(),
            topic: acl.topic.to_string(),
            ip: acl.ip.to_string(),
            action: acl.action.to_string(),
            permission: acl.permission.to_string(),
        })
        .collect();

    let sorted = apply_sorting(acls_list, &options);
    let pagination = apply_pagination(sorted, &options);

    success_response(PageReplyData {
        data: pagination.0,
        total_count: pagination.1,
    })
}

impl Queryable for AclListRow {
    fn get_field_str(&self, field: &str) -> Option<String> {
        match field {
            "tenant" => Some(self.tenant.clone()),
            "name" => Some(self.name.clone()),
            "resource_type" => Some(self.resource_type.clone()),
            "resource_name" => Some(self.resource_name.clone()),
            "topic" => Some(self.topic.clone()),
            "ip" => Some(self.ip.clone()),
            _ => None,
        }
    }
}

pub async fn acl_create(
    State(state): State<Arc<HttpState>>,
    ValidatedJson(params): ValidatedJson<CreateAclReq>,
) -> String {
    match acl_create_inner(&state, &params).await {
        Ok(_) => success_response("success"),
        Err(e) => error_response(e.to_string()),
    }
}

async fn acl_create_inner(state: &Arc<HttpState>, params: &CreateAclReq) -> ResultCommonError {
    let resource_type = match EnumAclResourceType::from_str(&params.resource_type) {
        Ok(data) => data,
        Err(e) => {
            return Err(CommonError::CommonError(e));
        }
    };

    let action = match EnumAclAction::from_str(&params.action) {
        Ok(data) => data,
        Err(e) => {
            return Err(CommonError::CommonError(e));
        }
    };

    let permission = match EnumAclPermission::from_str(&params.permission) {
        Ok(data) => data,
        Err(e) => {
            return Err(CommonError::CommonError(e));
        }
    };

    let mqtt_acl = SecurityAcl {
        name: params.name.clone(),
        desc: params.desc.clone().unwrap_or_default(),
        tenant: params.tenant.clone(),
        resource_type,
        resource_name: params.resource_name.clone(),
        topic: params.topic.clone().unwrap_or_default(),
        ip: params.ip.clone().unwrap_or_default(),
        action,
        permission,
    };

    let acl_storage = AclStorage::new(state.client_pool.clone());
    if let Err(e) = acl_storage.save_acl(mqtt_acl).await {
        return Err(CommonError::CommonError(e.to_string()));
    }
    Ok(())
}

pub async fn acl_delete(
    State(state): State<Arc<HttpState>>,
    ValidatedJson(params): ValidatedJson<DeleteAclReq>,
) -> String {
    match acl_delete_inner(&state, &params).await {
        Ok(_) => success_response("success"),
        Err(e) => error_response(e.to_string()),
    }
}

async fn acl_delete_inner(state: &Arc<HttpState>, params: &DeleteAclReq) -> ResultCommonError {
    let mqtt_acl = SecurityAcl {
        name: params.name.clone(),
        desc: String::new(),
        tenant: params.tenant.clone(),
        resource_type: EnumAclResourceType::ClientId,
        resource_name: String::new(),
        topic: String::new(),
        ip: String::new(),
        action: EnumAclAction::All,
        permission: EnumAclPermission::Allow,
    };

    let acl_storage = AclStorage::new(state.client_pool.clone());
    if let Err(e) = acl_storage.delete_acl(mqtt_acl).await {
        return Err(CommonError::CommonError(e.to_string()));
    }
    Ok(())
}
