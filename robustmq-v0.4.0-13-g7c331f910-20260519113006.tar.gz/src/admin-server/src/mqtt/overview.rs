// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use crate::state::HttpState;
use axum::extract::State;
use broker_core::cache::NodeCacheManager;
use common_base::{
    error::common::CommonError,
    http_response::{error_response, success_response},
};
use common_config::broker::broker_config;
use connector::manager::ConnectorManager;
use metadata_struct::meta::node::BrokerNode;
use mqtt_broker::{core::cache::MQTTCacheManager, subscribe::manager::SubscribeManager};
use network_server::common::connection_manager::ConnectionManager;
use rocksdb_engine::metrics::mqtt::MQTTMetricsCache;
use serde::{Deserialize, Serialize};
use std::sync::Arc;

#[derive(Clone, Serialize, Deserialize)]
pub struct OverViewResp {
    pub node_list: Vec<BrokerNode>,
    pub cluster_name: String,
    pub message_in_rate: u64,
    pub message_out_rate: u64,
    pub connection_num: u32,
    pub session_num: u32,
    pub topic_num: u32,
    pub tcp_connection_num: u32,
    pub tls_connection_num: u32,
    pub websocket_connection_num: u32,
    pub quic_connection_num: u32,
    pub subscribe_num: u32,
    pub exclusive_subscribe_num: u64,
    pub exclusive_subscribe_thread_num: u32,
    pub share_subscribe_group_num: u32,
    pub share_subscribe_num: u64,
    pub share_subscribe_thread_num: u32,
    pub connector_num: u32,
    pub connector_thread_num: u32,
}

pub async fn overview(State(state): State<Arc<HttpState>>) -> String {
    match cluster_overview_by_req(
        &state.mqtt_context.subscribe_manager,
        &state.connection_manager,
        &state.mqtt_context.cache_manager,
        &state.broker_cache,
        &state.mqtt_context.metrics_manager,
        &state.mqtt_context.connector_manager,
    )
    .await
    {
        Ok(data) => success_response(data),
        Err(e) => error_response(e.to_string()),
    }
}

async fn cluster_overview_by_req(
    subscribe_manager: &Arc<SubscribeManager>,
    connection_manager: &Arc<ConnectionManager>,
    cache_manager: &Arc<MQTTCacheManager>,
    broker_cache: &Arc<NodeCacheManager>,
    metrics_manager: &Arc<MQTTMetricsCache>,
    connector_manager: &Arc<ConnectorManager>,
) -> Result<OverViewResp, CommonError> {
    let config = broker_config();
    let node_list = broker_cache.node_list();

    let reply = OverViewResp {
        cluster_name: config.cluster_name.clone(),
        message_in_rate: metrics_manager.get_message_in_rate()?,
        message_out_rate: metrics_manager.get_message_out_rate()?,
        connector_num: connector_manager.connector_count() as u32,
        connector_thread_num: connector_manager.connector_thread_count() as u32,
        connection_num: cache_manager.get_connection_count() as u32,
        session_num: cache_manager.session_count() as u32,
        subscribe_num: subscribe_manager.subscribe_count() as u32,
        exclusive_subscribe_num: subscribe_manager.directly_push.sub_len(),
        exclusive_subscribe_thread_num: subscribe_manager.directly_push.buckets_data_list.len()
            as u32,
        share_subscribe_group_num: subscribe_manager.share_group_count() as u32,
        share_subscribe_num: subscribe_manager.share_sub_len(),
        share_subscribe_thread_num: subscribe_manager.share_group_count() as u32,
        topic_num: cache_manager.node_cache.topic_count() as u32,
        node_list,
        tcp_connection_num: connection_manager.tcp_write_list.len() as u32,
        tls_connection_num: connection_manager.tcp_tls_write_list.len() as u32,
        websocket_connection_num: connection_manager.websocket_write_list.len() as u32,
        quic_connection_num: connection_manager.quic_write_list.len() as u32,
    };

    Ok(reply)
}
