// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use crate::{
    state::HttpState,
    tool::extractor::ValidatedJson,
    tool::{
        query::{apply_pagination, apply_sorting, build_query_params, Queryable},
        PageReplyData,
    },
};
use axum::extract::{Query, State};
use mqtt_broker::{
    core::sub_share::{decode_share_info, get_share_sub_leader, is_mqtt_share_subscribe},
    subscribe::common::Subscriber,
};
use serde::{Deserialize, Serialize};
use validator::Validate;

#[derive(Serialize, Deserialize, Debug, Default)]
pub struct SubscribeListReq {
    pub tenant: Option<String>,
    pub client_id: Option<String>,
    pub limit: Option<u32>,
    pub page: Option<u32>,
    pub sort_field: Option<String>,
    pub sort_by: Option<String>,
}

#[derive(Deserialize, Debug)]
pub struct SubscribeDetailReq {
    pub tenant: String,
    pub client_id: String,
    pub path: String,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct SubscribeDetailRep {
    pub share_sub: bool,
    pub group_leader_info: Option<SubGroupLeaderRaw>,
    pub sub_data: SubDataRaw,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct SubDataRaw {
    pub tenant: String,
    pub client_id: String,
    pub path: String,
    // (topic, Subscriber)
    pub push_subscribe: HashMap<String, Subscriber>,
    // (topic, SubPushThreadDataRaw)
    pub push_thread: HashMap<String, SubPushThreadDataRaw>,

    pub leader_id: Option<u64>,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct SubGroupLeaderRaw {
    pub broker_id: u64,
    pub broker_addr: String,
    pub extend_info: String,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct SubPushThreadDataRaw {
    pub push_success_record_num: u64,
    pub push_error_record_num: u64,
    pub last_push_time: u64,
    pub last_run_time: u64,
    pub create_time: u64,
    pub bucket_id: String,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct SubPushThreadRaw {}

#[derive(Serialize, Deserialize, Debug, Default)]
pub struct AutoSubscribeListReq {
    pub tenant: Option<String>,
    pub name: Option<String>,
    pub limit: Option<u32>,
    pub page: Option<u32>,
    pub sort_field: Option<String>,
    pub sort_by: Option<String>,
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq, Validate)]
pub struct CreateAutoSubscribeReq {
    #[validate(length(min = 1, max = 256, message = "Name length must be between 1-256"))]
    pub name: String,

    pub desc: Option<String>,

    #[validate(length(min = 1, max = 256, message = "Tenant length must be between 1-256"))]
    pub tenant: String,

    #[validate(length(min = 1, max = 256, message = "Topic length must be between 1-256"))]
    pub topic: String,

    #[validate(range(max = 2, message = "QoS must be 0, 1 or 2"))]
    pub qos: u32,

    pub no_local: bool,
    pub retain_as_published: bool,

    #[validate(range(max = 2, message = "Retained handling must be 0, 1 or 2"))]
    pub retained_handling: u32,
}

#[derive(Serialize, Deserialize, Debug, Clone, PartialEq, Validate)]
pub struct DeleteAutoSubscribeReq {
    #[validate(length(min = 1, max = 256, message = "Tenant length must be between 1-256"))]
    pub tenant: String,

    #[validate(length(min = 1, max = 256, message = "Name length must be between 1-256"))]
    pub name: String,
}

#[derive(Clone, Serialize, Deserialize)]
pub struct SubscribeListRow {
    pub tenant: String,
    pub client_id: String,
    pub path: String,
    pub broker_id: u64,
    pub protocol: String,
    pub qos: String,
    pub no_local: u32,
    pub preserve_retain: u32,
    pub retain_handling: String,
    pub create_time: String,
    pub pk_id: u32,
    pub properties: String,
    pub is_share_sub: bool,
}

#[derive(Clone, Serialize, Deserialize)]
pub struct AutoSubscribeListRow {
    pub name: String,
    pub desc: String,
    pub tenant: String,
    pub topic: String,
    pub qos: String,
    pub no_local: bool,
    pub retain_as_published: bool,
    pub retained_handling: String,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct SlowSubscribeListReq {
    pub tenant: Option<String>,
    pub client_id: Option<String>,
    pub limit: Option<u32>,
    pub page: Option<u32>,
    pub sort_field: Option<String>,
    pub sort_by: Option<String>,
}

#[derive(Clone, Serialize, Deserialize)]
pub struct SlowSubscribeListRow {
    pub tenant: String,
    pub client_id: String,
    pub topic_name: String,
    pub time_span: u64,
    pub node_info: String,
    pub create_time: String,
    pub subscribe_name: String,
}

use common_base::{
    http_response::{error_response, success_response},
    utils::time_util::timestamp_to_local_datetime,
};
use metadata_struct::mqtt::auto_subscribe::MqttAutoSubscribeRule;
use mqtt_broker::storage::{auto_subscribe::AutoSubscribeStorage, local::LocalStorage};
use protocol::mqtt::common::{qos, retain_forward_rule};
use std::{collections::HashMap, sync::Arc};

pub async fn subscribe_list(
    State(state): State<Arc<HttpState>>,
    Query(params): Query<SubscribeListReq>,
) -> String {
    let tenant = params.tenant;
    let filter_client_id = params.client_id;
    let options = build_query_params(
        params.page,
        params.limit,
        params.sort_field,
        params.sort_by,
        None,
        None,
        None,
    );

    let subscribe_list = &state.mqtt_context.subscribe_manager.subscribe_list;
    let mut subscribes = Vec::new();

    let build_row = |sub: &metadata_struct::mqtt::subscribe::MqttSubscribe| SubscribeListRow {
        tenant: sub.tenant.clone(),
        broker_id: sub.broker_id,
        client_id: sub.client_id.clone(),
        create_time: timestamp_to_local_datetime(sub.create_time as i64),
        no_local: if sub.filter.no_local { 1 } else { 0 },
        path: sub.path.clone(),
        pk_id: sub.pkid as u32,
        preserve_retain: if sub.filter.preserve_retain { 1 } else { 0 },
        properties: serde_json::to_string(&sub.subscribe_properties).unwrap(),
        protocol: format!("{:?}", sub.protocol),
        qos: format!("{:?}", sub.filter.qos),
        retain_handling: format!("{:?}", sub.filter.retain_handling),
        is_share_sub: is_mqtt_share_subscribe(&sub.path),
    };

    let matches_client = |sub: &metadata_struct::mqtt::subscribe::MqttSubscribe| -> bool {
        filter_client_id
            .as_deref()
            .map(|keyword| sub.client_id.contains(keyword))
            .unwrap_or(true)
    };

    if let Some(ref t) = tenant {
        if let Some(tenant_map) = subscribe_list.get(t) {
            for entry in tenant_map.iter() {
                if matches_client(entry.value()) {
                    subscribes.push(build_row(entry.value()));
                }
            }
        }
    } else {
        for tenant_entry in subscribe_list.iter() {
            for entry in tenant_entry.value().iter() {
                if matches_client(entry.value()) {
                    subscribes.push(build_row(entry.value()));
                }
            }
        }
    }

    let sorted = apply_sorting(subscribes, &options);
    let pagination = apply_pagination(sorted, &options);

    success_response(PageReplyData {
        data: pagination.0,
        total_count: pagination.1,
    })
}

impl Queryable for SubscribeListRow {
    fn get_field_str(&self, field: &str) -> Option<String> {
        match field {
            "tenant" => Some(self.tenant.clone()),
            "client_id" => Some(self.client_id.clone()),
            _ => None,
        }
    }
}

pub async fn subscribe_detail(
    State(state): State<Arc<HttpState>>,
    Query(params): Query<SubscribeDetailReq>,
) -> String {
    let leader_id = if is_mqtt_share_subscribe(&params.path) {
        let (group, _) = decode_share_info(&params.path);
        get_share_sub_leader(&state.mqtt_context.cache_manager, &params.tenant, &group).await
    } else {
        None
    };

    let data = state
        .mqtt_context
        .subscribe_manager
        .directly_push
        .get_subscribe_data_by_sub(&params.client_id, &params.path);

    let mut push_subscribe = HashMap::new();
    let mut push_thread = HashMap::new();
    for (topic, (bucket_id, sub)) in data.iter() {
        push_subscribe.insert(topic.to_string(), sub.clone());
        if let Some(thread_data) = state
            .mqtt_context
            .push_manager
            .directly_buckets_push_thread
            .get(bucket_id)
        {
            let val = thread_data.value();
            push_thread.insert(
                topic.to_string(),
                SubPushThreadDataRaw {
                    bucket_id: bucket_id.to_string(),
                    push_error_record_num: val.push_error_record_num,
                    push_success_record_num: val.push_success_record_num,
                    last_push_time: val.last_push_time,
                    last_run_time: val.last_run_time,
                    create_time: val.create_time,
                },
            );
        }
    }

    let sub_data = SubDataRaw {
        tenant: params.tenant.clone(),
        client_id: params.client_id.clone(),
        path: params.path.clone(),
        push_subscribe,
        push_thread,
        leader_id,
    };

    success_response(SubscribeDetailRep {
        share_sub: false,
        sub_data,
        group_leader_info: None,
    })
}

pub async fn auto_subscribe_list(
    State(state): State<Arc<HttpState>>,
    Query(params): Query<AutoSubscribeListReq>,
) -> String {
    let filter_tenant = params.tenant;
    let filter_name = params.name;
    let options = build_query_params(
        params.page,
        params.limit,
        params.sort_field,
        params.sort_by,
        None,
        None,
        None,
    );
    let mut subscriptions = Vec::new();
    for tenant_entry in state.mqtt_context.cache_manager.auto_subscribe_rule.iter() {
        for rule_entry in tenant_entry.value().iter() {
            let raw = rule_entry.value();
            if filter_tenant
                .as_deref()
                .map(|t| !raw.tenant.contains(t))
                .unwrap_or(false)
            {
                continue;
            }
            if filter_name
                .as_deref()
                .map(|n| !raw.name.contains(n))
                .unwrap_or(false)
            {
                continue;
            }
            subscriptions.push(AutoSubscribeListRow {
                name: raw.name.clone(),
                desc: raw.desc.clone(),
                tenant: raw.tenant.clone(),
                topic: raw.topic.clone(),
                qos: format!("{:?}", raw.qos),
                no_local: raw.no_local,
                retain_as_published: raw.retain_as_published,
                retained_handling: format!("{:?}", raw.retained_handling),
            });
        }
    }

    let sorted = apply_sorting(subscriptions, &options);
    let pagination = apply_pagination(sorted, &options);

    success_response(PageReplyData {
        data: pagination.0,
        total_count: pagination.1,
    })
}

impl Queryable for AutoSubscribeListRow {
    fn get_field_str(&self, field: &str) -> Option<String> {
        match field {
            "name" => Some(self.name.clone()),
            "tenant" => Some(self.tenant.clone()),
            "topic" => Some(self.topic.clone()),
            _ => None,
        }
    }
}

pub async fn auto_subscribe_create(
    State(state): State<Arc<HttpState>>,
    ValidatedJson(params): ValidatedJson<CreateAutoSubscribeReq>,
) -> String {
    let qos_new = if let Some(qos) = qos(params.qos as u8) {
        qos
    } else {
        return error_response("Inconsistent QoS format".to_string());
    };

    let handing = if let Some(handing) = retain_forward_rule(params.retained_handling as u8) {
        handing
    } else {
        return error_response("Inconsistent RetainHandling format".to_string());
    };

    let auto_subscribe_rule = MqttAutoSubscribeRule {
        name: params.name.clone(),
        desc: params.desc.clone().unwrap_or_default(),
        tenant: params.tenant.clone(),
        topic: params.topic.clone(),
        qos: qos_new,
        no_local: params.no_local,
        retain_as_published: params.retain_as_published,
        retained_handling: handing,
    };

    let auto_subscribe_storage = AutoSubscribeStorage::new(state.client_pool.clone());
    if let Err(e) = auto_subscribe_storage
        .create_auto_subscribe_rule(auto_subscribe_rule.clone())
        .await
    {
        return error_response(e.to_string());
    }

    success_response("success")
}

pub async fn auto_subscribe_delete(
    State(state): State<Arc<HttpState>>,
    ValidatedJson(params): ValidatedJson<DeleteAutoSubscribeReq>,
) -> String {
    let auto_subscribe_storage = AutoSubscribeStorage::new(state.client_pool.clone());
    if let Err(e) = auto_subscribe_storage
        .delete_auto_subscribe_rule(params.tenant.clone(), params.name.clone())
        .await
    {
        return error_response(e.to_string());
    }

    success_response("success")
}

pub async fn slow_subscribe_list(
    State(state): State<Arc<HttpState>>,
    Query(params): Query<SlowSubscribeListReq>,
) -> String {
    let filter_tenant = params.tenant;
    let filter_client_id = params.client_id;
    let options = build_query_params(
        params.page,
        params.limit,
        params.sort_field,
        params.sort_by,
        None,
        None,
        None,
    );

    let local_storage = LocalStorage::new(state.rocksdb_engine_handler.clone());
    let data_list = match local_storage
        .list_slow_sub_log(filter_tenant.as_deref())
        .await
    {
        Ok(data) => data,
        Err(e) => {
            return error_response(e.to_string());
        }
    };

    let list_slow_subscribes = data_list
        .into_iter()
        .filter(|slow_data| {
            filter_client_id
                .as_deref()
                .map(|kw| slow_data.client_id.contains(kw))
                .unwrap_or(true)
        })
        .map(|slow_data| SlowSubscribeListRow {
            tenant: slow_data.tenant.clone(),
            client_id: slow_data.client_id.clone(),
            topic_name: slow_data.topic_name.clone(),
            time_span: slow_data.time_span,
            node_info: slow_data.node_info.clone(),
            create_time: timestamp_to_local_datetime(slow_data.create_time as i64),
            subscribe_name: slow_data.subscribe_name.clone(),
        })
        .collect::<Vec<_>>();

    let sorted = apply_sorting(list_slow_subscribes, &options);
    let pagination = apply_pagination(sorted, &options);

    success_response(PageReplyData {
        data: pagination.0,
        total_count: pagination.1,
    })
}

impl Queryable for SlowSubscribeListRow {
    fn get_field_str(&self, field: &str) -> Option<String> {
        match field {
            "tenant" => Some(self.tenant.clone()),
            "client_id" => Some(self.client_id.clone()),
            "topic_name" => Some(self.topic_name.clone()),
            _ => None,
        }
    }
}
