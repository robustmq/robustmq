// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#[cfg(test)]
mod test {
    use std::sync::Arc;

    use common_base::uuid::unique_id;
    use grpc_clients::{
        meta::mqtt::call::{
            placement_create_connector, placement_delete_connector, placement_list_connector,
            placement_update_connector,
        },
        pool::ClientPool,
    };
    use metadata_struct::connector::{
        config_kafka::KafkaConnectorConfig, config_local_file::LocalFileConnectorConfig,
        ConnectorType, MQTTConnector,
    };
    use protocol::meta::meta_service_mqtt::{
        CreateConnectorRequest, DeleteConnectorRequest, ListConnectorRequest,
        UpdateConnectorRequest,
    };

    use crate::common::get_placement_addr;

    fn check_connector_equal(left: &MQTTConnector, right: &MQTTConnector) {
        assert_eq!(left.connector_name, right.connector_name);
        assert_eq!(left.connector_type, right.connector_type);
        assert_eq!(left.topic_name, right.topic_name);
        assert_eq!(left.status.clone() as u8, right.status.clone() as u8);
        assert_eq!(left.broker_id, right.broker_id);
    }

    #[tokio::test]
    async fn connector_test() {
        let client_pool: Arc<ClientPool> = Arc::new(ClientPool::new(3));
        let addrs = vec![get_placement_addr()];

        let connector_name = unique_id();

        // create connector
        let mut connector = MQTTConnector {
            connector_name: connector_name.clone(),
            connector_type: ConnectorType::LocalFile(LocalFileConnectorConfig {
                local_file_path: "/tmp/test".to_string(),
                ..Default::default()
            }),
            topic_name: "test_topic-1".to_string(),
            tenant: "default".to_string(),
            ..Default::default()
        };

        let create_request = CreateConnectorRequest {
            connector_name: connector_name.clone(),
            connector: connector.encode().unwrap(),
        };
        placement_create_connector(&client_pool, &addrs, create_request)
            .await
            .unwrap();

        // list the connector we just created
        let list_request = ListConnectorRequest {
            connector_name: connector_name.clone(),
        };

        let mut stream = placement_list_connector(&client_pool, &addrs, list_request.clone())
            .await
            .unwrap();
        let mut count = 0;
        while let Some(reply) = stream.message().await.unwrap() {
            let mqtt_connector = MQTTConnector::decode(&reply.connector).unwrap();
            check_connector_equal(&mqtt_connector, &connector);
            count += 1;
        }
        assert_eq!(count, 1);

        // update connector
        connector.connector_type = ConnectorType::Kafka(KafkaConnectorConfig {
            bootstrap_servers: "127.0.0.1:9092".to_string(),
            topic: "test_topic".to_string(),
            key: "test_key".to_string(),
            ..Default::default()
        });
        connector.topic_name = "test_topic-2".to_string();

        let update_request = UpdateConnectorRequest {
            connector_name: connector_name.clone(),
            connector: connector.encode().unwrap(),
        };
        placement_update_connector(&client_pool, &addrs, update_request)
            .await
            .unwrap();

        // list the connector we just updated
        let mut stream = placement_list_connector(&client_pool, &addrs, list_request.clone())
            .await
            .unwrap();
        let mut count = 0;
        while let Some(reply) = stream.message().await.unwrap() {
            let mqtt_connector = MQTTConnector::decode(&reply.connector).unwrap();
            check_connector_equal(&mqtt_connector, &connector);
            count += 1;
        }
        assert_eq!(count, 1);

        // delete connector
        let delete_request = DeleteConnectorRequest {
            tenant: connector.tenant.clone(),
            connector_name: connector_name.clone(),
        };

        placement_delete_connector(&client_pool, &addrs, delete_request)
            .await
            .unwrap();

        // list connector should return nothing
        let mut stream = placement_list_connector(&client_pool, &addrs, list_request)
            .await
            .unwrap();
        let mut count = 0;
        while let Some(_reply) = stream.message().await.unwrap() {
            count += 1;
        }
        assert_eq!(count, 0);
    }
}
