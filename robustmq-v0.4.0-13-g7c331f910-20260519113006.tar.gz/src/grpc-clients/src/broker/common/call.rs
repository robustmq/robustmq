// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use common_base::error::common::CommonError;
use protocol::broker::broker::{
    GetQosDataByClientIdReply, GetQosDataByClientIdRequest, GetShardSegmentDeleteStatusReply,
    GetShardSegmentDeleteStatusRequest, SendLastWillMessageReply, SendLastWillMessageRequest,
    SendNatsShareGroupMessageReply, SendNatsShareGroupMessageRequest, UpdateCacheReply,
    UpdateCacheRequest,
};

use crate::pool::ClientPool;

macro_rules! generate_broker_call {
    ($fn_name:ident, $req_ty:ty, $rep_ty:ty) => {
        pub async fn $fn_name(
            client_pool: &ClientPool,
            addrs: &[impl AsRef<str>],
            request: $req_ty,
        ) -> Result<$rep_ty, CommonError> {
            $crate::utils::retry_call(client_pool, addrs, request).await
        }
    };
}

generate_broker_call!(broker_update_cache, UpdateCacheRequest, UpdateCacheReply);
generate_broker_call!(
    broker_send_last_will_message,
    SendLastWillMessageRequest,
    SendLastWillMessageReply
);
generate_broker_call!(
    broker_get_qos_data_by_client_id,
    GetQosDataByClientIdRequest,
    GetQosDataByClientIdReply
);

generate_broker_call!(
    broker_get_shard_segment_delete_status,
    GetShardSegmentDeleteStatusRequest,
    GetShardSegmentDeleteStatusReply
);

generate_broker_call!(
    broker_send_nats_share_group_message,
    SendNatsShareGroupMessageRequest,
    SendNatsShareGroupMessageReply
);
