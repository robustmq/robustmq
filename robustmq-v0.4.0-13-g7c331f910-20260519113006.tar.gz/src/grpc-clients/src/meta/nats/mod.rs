// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use protocol::meta::meta_service_nats::nats_service_client::NatsServiceClient;
use protocol::meta::meta_service_nats::{
    CreateNatsSubscribeReply, CreateNatsSubscribeRequest, DeleteNatsSubscribeReply,
    DeleteNatsSubscribeRequest, ListNatsSubscribeReply, ListNatsSubscribeRequest,
};
use tonic::transport::Channel;
use tonic::Streaming;

use crate::macros::impl_retriable_request;

pub mod call;

impl_retriable_request!(
    CreateNatsSubscribeRequest,
    NatsServiceClient<Channel>,
    CreateNatsSubscribeReply,
    create_nats_subscribe,
    "NatsService",
    "CreateNatsSubscribe",
    true
);

impl_retriable_request!(
    DeleteNatsSubscribeRequest,
    NatsServiceClient<Channel>,
    DeleteNatsSubscribeReply,
    delete_nats_subscribe,
    "NatsService",
    "DeleteNatsSubscribe",
    true
);

impl_retriable_request!(
    ListNatsSubscribeRequest,
    NatsServiceClient<Channel>,
    Streaming<ListNatsSubscribeReply>,
    list_nats_subscribe,
    "NatsService",
    "ListNatsSubscribe",
    true
);
