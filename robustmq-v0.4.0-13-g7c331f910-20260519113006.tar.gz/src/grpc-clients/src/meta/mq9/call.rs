// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use common_base::error::common::CommonError;
use protocol::meta::meta_service_mq9::{
    CreateAgentReply, CreateAgentRequest, CreateMailReply, CreateMailRequest, DeleteAgentReply,
    DeleteAgentRequest, DeleteMailReply, DeleteMailRequest, ListAgentReply, ListAgentRequest,
    ListMailReply, ListMailRequest, SearchAgentReply, SearchAgentRequest,
};
use tonic::Streaming;

use crate::pool::ClientPool;

macro_rules! generate_mq9_service_call {
    ($fn_name:ident, $req_ty:ty, $rep_ty:ty) => {
        pub async fn $fn_name(
            client_pool: &ClientPool,
            addrs: &[impl AsRef<str>],
            request: $req_ty,
        ) -> Result<$rep_ty, CommonError> {
            $crate::utils::retry_call(client_pool, addrs, request).await
        }
    };
}

generate_mq9_service_call!(
    placement_create_mq9_mail,
    CreateMailRequest,
    CreateMailReply
);
generate_mq9_service_call!(
    placement_delete_mq9_mail,
    DeleteMailRequest,
    DeleteMailReply
);
generate_mq9_service_call!(
    placement_list_mq9_mail,
    ListMailRequest,
    Streaming<ListMailReply>
);
generate_mq9_service_call!(
    placement_create_mq9_agent,
    CreateAgentRequest,
    CreateAgentReply
);
generate_mq9_service_call!(
    placement_delete_mq9_agent,
    DeleteAgentRequest,
    DeleteAgentReply
);
generate_mq9_service_call!(
    placement_list_mq9_agent,
    ListAgentRequest,
    Streaming<ListAgentReply>
);
generate_mq9_service_call!(
    placement_search_mq9_agent,
    SearchAgentRequest,
    SearchAgentReply
);
