// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use crate::error::BenchMarkError;
use crate::mqtt::common::{
    build_client, qos_from_u8, wait_connack_v4, wait_connack_v5, ClientHandle,
};
use crate::mqtt::report::{print_realtime_line, BenchReport, BenchReportInput, ThroughputSample};
use crate::mqtt::stats::SharedStats;
use crate::mqtt::{OutputFormat, SubscribeBenchArgs};
use rumqttc::{Event, Incoming};
use std::collections::BTreeMap;
use std::time::{Duration, Instant};
use tokio::task::JoinHandle;

pub async fn run_subscribe_bench(args: SubscribeBenchArgs) -> Result<(), BenchMarkError> {
    let duration = Duration::from_secs(args.duration_secs);
    let deadline = tokio::time::Instant::now() + duration;
    let qos = qos_from_u8(args.common.qos);
    let stats = SharedStats::new();
    let mut handles: Vec<JoinHandle<()>> = Vec::with_capacity(args.common.count);
    let mqtt_version = args.common.mqtt_version;

    for i in 0..args.common.count {
        if args.common.interval_ms > 0 {
            tokio::time::sleep(Duration::from_millis(args.common.interval_ms)).await;
        }
        let local_stats = stats.clone();
        let host = args.common.host.clone();
        let port = args.common.port;
        let username = args.common.username.clone();
        let password = args.common.password.clone();
        let topic = args.topic.clone();

        handles.push(tokio::spawn(async move {
            let client_id = format!("robust-bench-sub-{i}");
            let handle = build_client(&client_id, &host, port, &username, &password, mqtt_version);
            match handle {
                ClientHandle::V4(client, mut event_loop) => {
                    if let Err(e) = wait_connack_v4(&mut event_loop, 10_000).await {
                        local_stats.incr_failed();
                        local_stats.record_error(&format!("connect:{e}"));
                        return;
                    }
                    if let Err(e) = client.subscribe(topic, qos).await {
                        local_stats.incr_failed();
                        local_stats.record_error(&format!("subscribe:{e}"));
                        return;
                    }
                    while tokio::time::Instant::now() < deadline {
                        match tokio::time::timeout(Duration::from_millis(200), event_loop.poll())
                            .await
                        {
                            Ok(Ok(Event::Incoming(Incoming::Publish(_)))) => {
                                local_stats.incr_received();
                                local_stats.incr_success();
                            }
                            Ok(Ok(_)) => {}
                            Ok(Err(e)) => {
                                local_stats.incr_failed();
                                local_stats.record_error(&format!("poll:{e}"));
                            }
                            Err(_) => {
                                local_stats.incr_timeout();
                            }
                        }
                    }
                    let _ = client.disconnect().await;
                }
                ClientHandle::V5(client, mut event_loop) => {
                    if let Err(e) = wait_connack_v5(&mut event_loop, 10_000).await {
                        local_stats.incr_failed();
                        local_stats.record_error(&format!("connect:{e}"));
                        return;
                    }
                    let v5_qos = match qos {
                        rumqttc::QoS::AtMostOnce => rumqttc::v5::mqttbytes::QoS::AtMostOnce,
                        rumqttc::QoS::AtLeastOnce => rumqttc::v5::mqttbytes::QoS::AtLeastOnce,
                        rumqttc::QoS::ExactlyOnce => rumqttc::v5::mqttbytes::QoS::ExactlyOnce,
                    };
                    if let Err(e) = client.subscribe(topic, v5_qos).await {
                        local_stats.incr_failed();
                        local_stats.record_error(&format!("subscribe:{e}"));
                        return;
                    }
                    while tokio::time::Instant::now() < deadline {
                        use rumqttc::v5::{Event as EventV5, Incoming as IncomingV5};
                        match tokio::time::timeout(Duration::from_millis(200), event_loop.poll())
                            .await
                        {
                            Ok(Ok(EventV5::Incoming(IncomingV5::Publish(_)))) => {
                                local_stats.incr_received();
                                local_stats.incr_success();
                            }
                            Ok(Ok(_)) => {}
                            Ok(Err(e)) => {
                                local_stats.incr_failed();
                                local_stats.record_error(&format!("poll:{e}"));
                            }
                            Err(_) => {
                                local_stats.incr_timeout();
                            }
                        }
                    }
                    let _ = client.disconnect().await;
                }
            }
        }));
    }

    let monitor_stats = stats.clone();
    let monitor = tokio::spawn(async move {
        let mut series = Vec::new();
        let mut prev = 0;
        let begin = Instant::now();
        while tokio::time::Instant::now() < deadline {
            tokio::time::sleep(Duration::from_secs(1)).await;
            let current = monitor_stats
                .counters
                .received
                .load(std::sync::atomic::Ordering::Relaxed);
            let delta = current.saturating_sub(prev);
            let snapshot = monitor_stats.snapshot();
            print_realtime_line("sub", begin.elapsed(), delta, current, &snapshot);
            series.push(ThroughputSample {
                second: begin.elapsed().as_secs(),
                ops_per_sec: delta,
                total_ops: current,
                success: snapshot.success,
                failed: snapshot.failed,
                timeout: snapshot.timeout,
                received: snapshot.received,
            });
            prev = current;
        }
        series
    });

    for handle in handles {
        let _ = handle.await;
    }
    let series = monitor.await.unwrap_or_default();
    let snapshot = stats.snapshot();
    let total_ops = snapshot.received;
    let mut extras = BTreeMap::new();
    extras.insert("mode".to_string(), "tcp-sub".to_string());
    extras.insert("topic".to_string(), args.topic);
    extras.insert("qos".to_string(), args.common.qos.to_string());
    extras.insert(
        "interval_ms".to_string(),
        args.common.interval_ms.to_string(),
    );

    let report = BenchReport::from_input(
        BenchReportInput {
            name: "mqtt-sub".to_string(),
            host: args.common.host,
            port: args.common.port,
            duration_secs: duration.as_secs(),
            clients: args.common.count,
            op_label: "received_messages".to_string(),
            total_ops,
            connect_phase_secs: None,
            connect_qps: None,
            extras,
            series,
        },
        snapshot,
    );
    match args.common.output {
        OutputFormat::Table => report.print_table(),
        OutputFormat::Json => report.print_json(),
    }
    Ok(())
}
