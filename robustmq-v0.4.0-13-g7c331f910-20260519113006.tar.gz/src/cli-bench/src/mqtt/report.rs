// Copyright 2023 RobustMQ Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use crate::mqtt::stats::StatsSnapshot;
use prettytable::{row, Table};
use serde::Serialize;
use std::collections::BTreeMap;
use std::io::{self, Write};
use std::time::Duration;

#[derive(Debug, Clone, Serialize)]
pub struct ThroughputSample {
    pub second: u64,
    pub ops_per_sec: u64,
    pub total_ops: u64,
    pub success: u64,
    pub failed: u64,
    pub timeout: u64,
    pub received: u64,
}

#[derive(Debug, Clone, Serialize)]
pub struct BenchReport {
    pub name: String,
    pub host: String,
    pub port: u16,
    pub duration_secs: u64,
    pub clients: usize,
    pub op_label: String,
    pub total_ops: u64,
    pub connect_phase_secs: Option<f64>,
    pub connect_qps: Option<f64>,
    pub avg_ops_per_sec: f64,
    pub peak_ops_per_sec: u64,
    pub success_rate: f64,
    pub error_rate: f64,
    pub timeout_rate: f64,
    pub extras: BTreeMap<String, String>,
    pub series: Vec<ThroughputSample>,
    pub snapshot: StatsSnapshot,
}

#[derive(Debug, Clone)]
pub struct BenchReportInput {
    pub name: String,
    pub host: String,
    pub port: u16,
    pub duration_secs: u64,
    pub clients: usize,
    pub op_label: String,
    pub total_ops: u64,
    pub connect_phase_secs: Option<f64>,
    pub connect_qps: Option<f64>,
    pub extras: BTreeMap<String, String>,
    pub series: Vec<ThroughputSample>,
}

impl BenchReport {
    pub fn from_input(input: BenchReportInput, snapshot: StatsSnapshot) -> Self {
        let avg_ops_per_sec = if input.duration_secs == 0 {
            0.0
        } else {
            input.total_ops as f64 / input.duration_secs as f64
        };
        let peak_ops_per_sec = input
            .series
            .iter()
            .map(|s| s.ops_per_sec)
            .max()
            .unwrap_or(0);
        let total_attempts = snapshot.success + snapshot.failed + snapshot.timeout;
        let (success_rate, error_rate, timeout_rate) = if total_attempts == 0 {
            (0.0, 0.0, 0.0)
        } else {
            (
                snapshot.success as f64 * 100.0 / total_attempts as f64,
                snapshot.failed as f64 * 100.0 / total_attempts as f64,
                snapshot.timeout as f64 * 100.0 / total_attempts as f64,
            )
        };

        Self {
            name: input.name,
            host: input.host,
            port: input.port,
            duration_secs: input.duration_secs,
            clients: input.clients,
            op_label: input.op_label,
            total_ops: input.total_ops,
            connect_phase_secs: input.connect_phase_secs,
            connect_qps: input.connect_qps,
            avg_ops_per_sec,
            peak_ops_per_sec,
            success_rate,
            error_rate,
            timeout_rate,
            extras: input.extras,
            series: input.series,
            snapshot,
        }
    }

    pub fn print_table(&self) {
        println!("\n=== Benchmark Summary ===");
        let mut table = Table::new();
        table.set_titles(row!["metric", "value"]);
        table.add_row(row!["name", self.name.as_str()]);
        table.add_row(row!["target", format!("{}:{}", self.host, self.port)]);
        table.add_row(row!["duration(s)", self.duration_secs]);
        table.add_row(row!["clients", self.clients]);
        table.add_row(row!["op_label", self.op_label.as_str()]);
        table.add_row(row!["total_ops", self.total_ops]);
        if let Some(secs) = self.connect_phase_secs {
            table.add_row(row!["connect_phase_secs", format!("{secs:.3}")]);
        }
        if let Some(qps) = self.connect_qps {
            table.add_row(row!["connect_qps", format!("{qps:.2}")]);
        }
        table.add_row(row![
            "📈 avg_ops_per_sec",
            format!("{:.2}", self.avg_ops_per_sec)
        ]);
        table.add_row(row!["🚀 peak_ops_per_sec", self.peak_ops_per_sec]);
        table.add_row(row!["success", self.snapshot.success]);
        table.add_row(row!["failed", self.snapshot.failed]);
        table.add_row(row!["timeout", self.snapshot.timeout]);
        table.add_row(row!["received", self.snapshot.received]);
        table.add_row(row!["success_rate(%)", format!("{:.4}", self.success_rate)]);
        table.add_row(row!["error_rate(%)", format!("{:.4}", self.error_rate)]);
        table.add_row(row!["timeout_rate(%)", format!("{:.4}", self.timeout_rate)]);
        table.add_row(row![
            "⏱️ latency_avg(ms)",
            format!("{:.3}", self.snapshot.latency_ms_avg)
        ]);
        table.add_row(row![
            "🟢 latency_p50(ms)",
            format!("{:.3}", self.snapshot.latency_ms_p50)
        ]);
        table.add_row(row![
            "🟠 latency_p95(ms)",
            format!("{:.3}", self.snapshot.latency_ms_p95)
        ]);
        table.add_row(row![
            "🔴 latency_p99(ms)",
            format!("{:.3}", self.snapshot.latency_ms_p99)
        ]);
        table.add_row(row![
            "🟣 latency_p999(ms)",
            format!("{:.3}", self.snapshot.latency_ms_p999)
        ]);
        table.add_row(row![
            "⚫ latency_p9999(ms)",
            format!("{:.3}", self.snapshot.latency_ms_p9999)
        ]);
        table.add_row(row![
            "latency_min(ms)",
            format!("{:.3}", self.snapshot.latency_ms_min)
        ]);
        table.add_row(row![
            "latency_max(ms)",
            format!("{:.3}", self.snapshot.latency_ms_max)
        ]);
        table.printstd();

        if !self.snapshot.errors.is_empty() {
            println!("\n=== Errors ===");
            let mut err_table = Table::new();
            err_table.set_titles(row!["error", "count"]);
            for (msg, count) in &self.snapshot.errors {
                err_table.add_row(row![msg, count]);
            }
            err_table.printstd();
        }
    }

    pub fn print_json(&self) {
        match serde_json::to_string_pretty(self) {
            Ok(raw) => println!("{raw}"),
            Err(e) => eprintln!("failed to print json report: {e}"),
        }
    }
}

pub fn print_realtime_line(
    stage: &str,
    elapsed: Duration,
    delta_ops: u64,
    total_ops: u64,
    snapshot: &StatsSnapshot,
) {
    println!(
        "[{}] sec={} | ops/s={} | total={} | success={} | failed={} | timeout={} | recv={} | p95={:.3}ms p99={:.3}ms p999={:.3}ms p9999={:.3}ms",
        stage,
        elapsed.as_secs(),
        delta_ops,
        total_ops,
        snapshot.success,
        snapshot.failed,
        snapshot.timeout,
        snapshot.received,
        snapshot.latency_ms_p95,
        snapshot.latency_ms_p99,
        snapshot.latency_ms_p999,
        snapshot.latency_ms_p9999
    );
    if !snapshot.errors.is_empty() {
        for (msg, count) in &snapshot.errors {
            println!("  [error] {} x{}", msg, count);
        }
    }
}

pub fn print_conn_progress_line(
    elapsed: Duration,
    total: u64,
    success: u64,
    failed: u64,
    done: bool,
) {
    let completed = success + failed;
    let pending = total.saturating_sub(completed);
    let progress = if total == 0 {
        100.0
    } else {
        completed as f64 * 100.0 / total as f64
    };

    let line = format!(
        "[conn-progress] sec={} | total={} | success={} | failed={} | pending={} | progress={:.2}%",
        elapsed.as_secs(),
        total,
        success,
        failed,
        pending,
        progress
    );

    if done {
        print!("\r{line}    \n");
    } else {
        print!("\r{line}    ");
    }
    let _ = io::stdout().flush();
}
